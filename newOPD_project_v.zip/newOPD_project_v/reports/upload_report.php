<?php
// Start the session
session_start();

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Database connection settings
    $servername = "localhost";
    $db_username = "root";
    $db_password = "";
    $database = "opd_management";
    

    // Connect to the database
    $conn = new mysqli($servername, $db_username, $db_password, $database);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Get username from POST (hidden input)
    

    // Get form data
    $report_name = $_POST['report_name'];
    $report_date = date("Y-m-d");

    // File upload setup
    $target_dir = $_SERVER['DOCUMENT_ROOT'] . "/OPD_Project/reports/uploads/";
    $target_file = $target_dir . basename($_FILES["report_file"]["name"]);
    $file_path = "/OPD_Project/reports/uploads/" . basename($_FILES["report_file"]["name"]);

    // Create folder if not exists
    if (!is_dir($target_dir)) {
        mkdir($target_dir, 0777, true);
    }

    // Move uploaded file
    if (move_uploaded_file($_FILES["report_file"]["tmp_name"], $target_file)) {
        // Use prepared statement to insert data
        $stmt = $conn->prepare("INSERT INTO lab_reports (username, report_name, report_date, file_path) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("ssss", $username, $report_name, $report_date, $file_path);

        if ($stmt->execute()) {
            echo "<p>Report uploaded successfully!</p>";
            echo "<script>setTimeout(function(){ window.location.href = '../admin/manage_patients.php'; }, 3000);</script>";
        } else {
            echo "<p>Error: " . $stmt->error . "</p>";
        }

        $stmt->close();
    } else {
        echo "<p>Error uploading file. Check folder permissions and file path.</p>";
    }

    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Upload Lab Report</title>
    <link rel="stylesheet" href="./upload_report_style.css">
</head>
<body>
<h2>Upload Lab Report</h2>
<form method="POST" enctype="multipart/form-data">
    <?php
    // Automatically fill username from URL using ?id=
    $id = isset($_GET['id']) ? htmlspecialchars($_GET['id']) : '';

    if (!$id) {
        echo "<p style='color:red;'>Error: Patient ID not specified in the URL.</p>";
        exit;
    }
    ?>

    <!-- Hidden username input -->
    <input type="hidden" name="username" value="<?php echo $id; ?>">

    <!-- Show patient ID just for user reference -->
    <p><strong>Patient ID:</strong> <?php echo $id; ?></p>
   


    
    Report Name: <input type="text" name="report_name" required><br><br>

    Report File: <input type="file" name="report_file" required><br><br>

    <button type="submit">Upload Report</button>
    <button type="reset">Reset</button>
</form>
</body>
</html>
