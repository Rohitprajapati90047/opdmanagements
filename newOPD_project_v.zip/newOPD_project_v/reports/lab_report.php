<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="labreport.css">
</head>
<body>
<?php include '../patient/nav/back.html'; ?>
    
<?php
// Start session to access session variables
session_start();  

// Check if the session has a username or patient ID
if (isset($_SESSION['username'])) {
    $username = $_SESSION['username'];  // Use the username as patient ID or fetch ID from the database
} else {
    die("Patient ID not specified. Please log in.");
}

// Database connection
$servername = "localhost";
$user = "root";
$password = "";
$database = "opd_management";

$conn = new mysqli($servername, $user, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch the lab reports for the patient
$sql = "SELECT report_name, report_date, file_path FROM lab_reports WHERE username = '$username'";
$result = $conn->query($sql);

echo "<h2>Lab Reports for Patient ID: " .$username. "</h2>";

if ($result->num_rows > 0) {
    echo "<table border='1' cellpadding='5'>
            <tr>
                <th>Report Name</th>
                <th>Report Date</th>
                <th>View Report</th>
                <th>Download</th>
            </tr>";
    while ($row = $result->fetch_assoc()) {
        echo "<tr>
                <td>" . $row['report_name'] . "</td>
                <td>" . $row['report_date'] . "</td>
                <td><a href='" . $row['file_path'] . "' target='_blank'>View Report</a></td>
                <td><a href='/" . $row['file_path'] . "' download>Download</a></td>
              </tr>";
    }
    echo "</table>";
} else {
    echo "<p>No lab reports found for this patient.</p>";
}

$conn->close();
?>

</body>
</html>




