<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: ./login.php");
    exit();
}

$host = "localhost";
$user = "root";
$password = "";
$database = "opd_management";
$conn = mysqli_connect($host, $user, $password, $database);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$username = $_SESSION['username'];

// Fetch patient details including age from the database
$query = "SELECT *, TIMESTAMPDIFF(YEAR, dob, CURDATE()) AS age FROM patient WHERE username='$username'";
$result = mysqli_query($conn, $query);
$patient = mysqli_fetch_assoc($result);

// Check if patient data exists
if (!$patient) {
    die("Patient not found");
}

$query = "SELECT rc.patient_name, rc.visit_date, rc.reason, rc.disease_type, rc.opd_room 
          FROM renew_case rc 
          JOIN patient p ON CONCAT(p.fname, ' ', p.lname) = rc.patient_name 
          WHERE p.username = ?
           ORDER BY rc.visit_date DESC
           LIMIT 3";
$stmt = mysqli_prepare($conn, $query);
if (!$stmt) {
    die("Statement preparation failed: " . mysqli_error($conn));
}
mysqli_stmt_bind_param($stmt, "s", $username);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
if (!$result) {
    die("Query execution failed: " . mysqli_error($conn));
}

// for medicine prection 
// $selected_date = isset($_POST['prescription_date']) ? $_POST['prescription_date'] : date('Y-m-d');

// // Fetch disease and medicine information from the database
// $query = "SELECT p.*, pm.medicine_name, pm.dosage, pm.duration, d.name as doctor_name
//         FROM prescriptions p
//         JOIN prescription_medicines pm ON p.id = pm.prescription_id
//         JOIN patient pat ON p.patient_id = pat.patient_id
//         JOIN doctors d ON p.doctor_id = d.id
//         WHERE pat.username = ? AND DATE(p.created_at) = ?";
// $stmt = $conn->prepare($query);
// if ($stmt === false) {
//     die('Prepare failed: ' . htmlspecialchars($conn->error));
// }
// $stmt->bind_param("ss", $username, $selected_date);
// $stmt->execute();
// $result = $stmt->get_result();
// if ($result === false) {
//     die('Execute failed: ' . htmlspecialchars($stmt->error));
// }

// // Fetch the doctor's name
// $doctor_name = '';
// if ($row = $result->fetch_assoc()) {
//     $doctor_name = $row['doctor_name'];
//     $result->data_seek(0); // Reset result pointer to the beginning
// }
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - OPD Management</title>
    <link rel="stylesheet" href="newdashboard_style.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <style>
        .popup-alert {
            position: fixed;
            top: 20px;
            right: 20px;
            z-index: 9999;
            min-width: 300px;
        }
        /* General button styling */
.dashboard-container button {
    margin: 10px;
    padding: 12px 24px; /* Adjust padding for mobile-friendly size */
    font-size: 1.2rem;  /* Use rem for font size to make it responsive */
    display: inline-flex;
    align-items: center;
    gap: 12px;
    background-color: rgb(7, 230, 207);
    color: white;
    border: none;
    border-radius: 10px;
    cursor: pointer;
    transition: background-color 0.3s, transform 0.3s, box-shadow 0.3s ease-in-out;
    box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);
}

/* Hover Effect */
.dashboard-container button:hover {
    background-color: rgb(0, 204, 190);
    transform: scale(1.05); /* Slight zoom effect on hover */
    box-shadow: 0px 8px 15px rgba(0, 0, 0, 0.2);
}

/* Focus Effect */
.dashboard-container button:focus {
    outline: none;
    box-shadow: 0 0 0 4px rgba(7, 230, 207, 0.5);
}

/* Icon styling inside buttons */
.dashboard-container button i {
    font-size: 1.5rem;  /* Make the icon size responsive */
    transition: transform 0.3s ease-in-out;
}

.dashboard-container button:hover i {
    transform: rotate(15deg); /* Add slight rotation to icons on hover */
}

/* Icon color per button type */
.appointment-icon { color: #4CAF50; }       /* Green */
.report-icon { color: #2196F3; }            /* Blue */
.medicine-icon { color: #FF5722; }          /* Orange */
.billing-icon { color: #9C27B0; }           /* Purple */
.operation-icon { color: #E91E63; }         /* Pink */
.lab-icon { color: #FFC107; }               /* Amber */
.transfer-icon { color: #607D8B; }          /* Gray */
.account-icon { color: #673AB7; }           /* Deep Purple */

/* Active/Selected state for the button (optional) */
.dashboard-container button.active {
    background-color: #03A9F4;
    box-shadow: 0px 6px 10px rgba(0, 0, 0, 0.2);
}

/* Responsive adjustments */
@media (max-width: 768px) {
    /* For smaller devices (tablets and smaller screens) */
    .dashboard-container button {
        padding: 10px 20px;  /* Reduced padding for smaller screens */
        font-size: 1rem;     /* Slightly smaller text size */
    }

    .dashboard-container button i {
        font-size: 1.3rem;  /* Make the icons slightly smaller on small screens */
    }
}

@media (max-width: 480px) {
    /* For very small screens (phones in portrait mode) */
    .dashboard-container button {
        padding:  30px;   /* Even smaller padding for small devices */
        font-size: 0.9rem;    /* Smaller font size */
        margin-left: 0px;
        width: 100%;          /* Make the buttons take full width */
    }

    .dashboard-container button i {
        font-size: 1.2rem;   /* Adjust icon size to fit on small screens */
    }
}


        </style>
</head>
<body>
    <div class="dashboard-wrapper">
        <!-- Sidebar -->
        <aside class="sidebar">
            <div class="sidebar-header">
                <div class="logo">
                    <i class="material-icons">medical_services</i>
                    <h2>OPD Management</h2>
                </div>
                <button class="close-sidebar" id="closeSidebar">
                    <i class="material-icons">close</i>
                </button>
            </div>
            
            <nav class="sidebar-nav">
                <div class="nav-section">
                    <h3>Main Menu</h3>
                    <ul>
                        <li class="active">
                            <a href="#">
                                <i class="material-icons">dashboard</i>
                                <span>Dashboard</span>
                            </a>
                        </li>
                    </ul>
                </div>
                
                <div class="nav-section">
                    <h3>Account</h3>
                    <ul>
                        <li>
                            <a href="./profile/view_profile.php">
                                <i class="material-icons">person</i>
                                <span>Profile</span>
                            </a>
                        </li>
                    </ul>
                </div>
            </nav>
            
            <div class="sidebar-footer">
                <div class="user-info">
                    <div class="user-avatar">
                        <span><?php echo strtoupper(substr($patient['fname'], 0, 1) . substr($patient['lname'], 0, 1)); ?></span>
                    </div>
                    <div class="user-details">
                        <p class="user-name"><?php echo $patient['fname'] . " " . $patient['lname']; ?></p>
                        <p class="user-id">Patient ID: <?php echo $patient['patient_id']; ?></p>
                    </div>
                </div>
            </div>
        </aside>

        <!-- Main Content -->
        <main class="main-content">
            <header class="main-header">
                <button class="menu-toggle" id="menuToggle">
                    <i class="material-icons">menu</i>
                </button>
                <h1>Patient Dashboard</h1>
                <div class="header-actions"> 
                     
                    <a href="../index.php" class="notification-btn"> 
                     <i class="material-icons">logout</i> 

                    </a> 
                </div> 
            </header>

            <div class="welcome-banner">
                <h2>Welcome back, <?php echo $patient['fname'] . " " . $patient['lname']; ?></h2>
                <p>Here's a summary of your health information</p>
            </div>

            <!-- Patient Info Card -->
            <section class="card patient-info">
                <div class="card-header">
                    <h2>Patient Information</h2>
                </div>
                <div class="card-body">
                    <div class="info-grid">
                        <div class="info-item">
                            <label>Full Name</label>
                            <p><?php echo $patient['fname'] . " " . $patient['lname']; ?></p>
                        </div>
                        <div class="info-item">
                            <label>Patient ID</label>
                            <p><?php echo $patient['patient_id']; ?></p>
                        </div>
                        <div class="info-item">
                            <label>Age</label>
                            <p><?php echo $patient['age']; ?> years</p>
                        </div>
                        <div class="info-item">
                            <label>Gender</label>
                            <p><?php echo $patient['gender']; ?></p>
                        </div>
                        <div class="info-item">
                            <label>Phone</label>
                            <p><?php echo $patient['phone']; ?></p>
                        </div>
                        <div class="info-item">
                            <label>Email</label>
                            <p><?php echo $patient['email']; ?></p>
                        </div>
                    </div>
                </div>
            </section>

            <!-- Dashboard Buttons (Replaced with buttons from first file) -->
            <section class="dashboard-container">
                <button onclick="window.location.href='renew_case.php'">
                    <i class="material-icons appointment-icon">event_available</i> Appointment
                </button>
                <button onclick="window.location.href='patient_report.php'">
                    <i class="material-icons report-icon">assignment</i> Appointment History
                </button>
                <button onclick="window.location.href='disease_medicine.php'">
                    <i class="material-icons medicine-icon">medical_services</i> Disease and Medicine
                </button>
                <button onclick="window.location.href='billing.php'">
                    <i class="material-icons billing-icon">receipt</i> Billing
                </button>
                <button onclick="window.location.href='operation_info.php'">
                    <i class="material-icons operation-icon">healing</i> Operation Info
                </button>
                <button onclick="window.location.href='../reports/lab_report.php'">
                    <i class="material-icons lab-icon">science</i> Laboratory Report
                </button>
                <button onclick="window.location.href='ecard.php'">
                    <i class="material-icons account-icon">C</i> E-Card
                </button>
                <button onclick="window.location.href='future.php'">
                    <i class="material-icons account-icon">O</i> Future work
                </button>
            </section>

            <!-- Two Column Layout for Appointments and Prescriptions -->
            <div class="two-column">
                <!-- Upcoming Appointments -->
                <section class="card">
                    <div class="card-header">
                        <h2>Upcoming Appointments</h2>
                    </div>
                    <div class="card-body">
                    <?php if (mysqli_num_rows($result) > 0): ?>
    <div class="appointments-container">
        <?php while ($row = mysqli_fetch_assoc($result)): ?>
            <div class="appointment-card">
                <p><strong>Patient Name:</strong> <?php echo htmlspecialchars($row['patient_name']); ?></p>
                <p><strong>Visit Date:</strong> <?php echo htmlspecialchars($row['visit_date']); ?></p>
                <p><strong>Reason:</strong> <?php echo htmlspecialchars($row['reason']); ?></p>
                <p><strong>Disease Type:</strong> <?php echo htmlspecialchars($row['disease_type']); ?></p>
                <p><strong>OPD Room:</strong> <?php echo htmlspecialchars($row['opd_room']); ?></p>
            </div>
            <p>===============================================================</p>
        <?php endwhile; ?>
    </div>
<?php else: ?>
    <p>No records found.</p>
<?php endif; ?><!-- Dynamically generate appointment items here -->
                    </div>
                </section>

                <!-- Recent Prescriptions -->
                <section class="card">
                <div class="card-header">
    <h2>Recent Prescriptions</h2>
</div>
<div class="card-body">
    <?php
    // Fetch disease and medicine information from the database
    $query = "SELECT p.*, pm.medicine_name, pm.dosage, pm.duration, d.name as doctor_name
          FROM prescriptions p
          JOIN prescription_medicines pm ON p.id = pm.prescription_id
          JOIN patient pat ON p.patient_id = pat.patient_id
          JOIN doctors d ON p.doctor_id = d.id
          WHERE pat.username = ?";

    $stmt = $conn->prepare($query);
    if ($stmt === false) {
        die('Prepare failed: ' . htmlspecialchars($conn->error));
    }
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result === false) {
        die('Execute failed: ' . htmlspecialchars($stmt->error));
    }

    // Fetch the doctor's name
    $doctor_name = '';
    if ($row = $result->fetch_assoc()) {
        $doctor_name = $row['doctor_name'];
        $result->data_seek(0); // Reset result pointer to the beginning
    }
    ?>
    <!-- Dynamically generate prescription items here -->
    <?php if ($result->num_rows > 0): ?>
        <!-- Disease Information -->
        <p style="margin-bottom: 10px;"><strong>Disease:</strong></p>
        <?php while ($row = $result->fetch_assoc()): ?>
            <p style="margin-left: 20px;"><?php echo htmlspecialchars($row['disease']); ?></p>
        <?php endwhile; ?>

        <!-- Medicine Information -->
        <p style="margin-top: 20px;"><strong>Medicine:</strong></p>
        <?php 
        $result->data_seek(0); // Reset pointer to the beginning
        while ($row = $result->fetch_assoc()): ?>
            <p style="margin-left: 20px;">
                <?php echo htmlspecialchars($row['medicine_name']); ?> - 
                <span>Dose: <?php echo htmlspecialchars($row['dosage']); ?></span> - 
                <span>Duration: <?php echo htmlspecialchars($row['duration']); ?></span>
                <p>Prescription Date: <?php echo htmlspecialchars($row['created_at']); ?></p>
            </p>
        <?php endwhile; ?>

        <!-- Doctor Information -->
        <!-- Doctor and Date Information -->
<div style="margin-top: 40px;">
    <p>Doctor Name: <?php echo htmlspecialchars($doctor_name); ?></p>
    <p>Doctor Degree: MBBS, MD</p>
</div>

    <?php else: ?>
        <!-- No Prescription Message -->
        <div style="text-align: center; margin-top: 50px;">
            <p style="color: red; font-weight: bold;">No prescription by doctor.</p>
        </div>
    <?php endif; ?>
    <p>===============================================================</p>
</div>

                </section>
            </div>
        </main>
    </div>

    <!-- Popup Alert Container -->
    <div class="popup-alert" id="alertContainer"></div>

    <script>
        // Simple JavaScript for sidebar toggle
        document.addEventListener('DOMContentLoaded', function() {
            const menuToggle = document.getElementById('menuToggle');
            const closeSidebar = document.getElementById('closeSidebar');
            const sidebar = document.querySelector('.sidebar');
            const dashboardWrapper = document.querySelector('.dashboard-wrapper');
            
            menuToggle.addEventListener('click', function() {
                dashboardWrapper.classList.toggle('sidebar-open');
            });
            
            closeSidebar.addEventListener('click', function() {
                dashboardWrapper.classList.remove('sidebar-open');
            });
            
            // Close sidebar when clicking outside on mobile
            document.addEventListener('click', function(event) {
                if (window.innerWidth <= 768 && 
                    dashboardWrapper.classList.contains('sidebar-open') && 
                    !sidebar.contains(event.target) && 
                    event.target !== menuToggle) {
                    dashboardWrapper.classList.remove('sidebar-open');
                }
            });
        });
    </script>
</body>
</html>
