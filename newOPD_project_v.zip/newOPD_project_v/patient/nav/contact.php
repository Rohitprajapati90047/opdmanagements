<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Us - OPD Management System</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Arial', sans-serif;
        }

        :root {
            --primary-color: #1e88e5;
            --secondary-color: #0d47a1;
            --accent-color: #64b5f6;
            --text-color: #333;
            --light-color: #f5f5f5;
            --dark-color: #212121;
        }

        body {
            background-color: #f8f9fa;
            color: var(--text-color);
            line-height: 1.6;
        }

        header {
            background-color: var(--primary-color);
            color: white;
            padding: 1rem 0;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            position: sticky;
            top: 0;
            z-index: 100;
        }

        .container {
            width: 90%;
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 15px;
        }

        .header-content {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .logo {
            font-size: 1.8rem;
            font-weight: bold;
            text-decoration: none;
            color: white;
        }

        nav ul {
            display: flex;
            list-style: none;
        }

        nav ul li {
            margin-left: 1.5rem;
        }

        nav ul li a {
            color: white;
            text-decoration: none;
            font-weight: 500;
            transition: color 0.3s;
        }

        nav ul li a:hover {
            color: var(--accent-color);
        }

        .hero {
            background-image: linear-gradient(rgba(0, 0, 0, 0.6), rgba(0, 0, 0, 0.6)), url('https://images.unsplash.com/photo-1579684385127-1ef15d508118?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80');
            background-size: cover;
            background-position: center;
            color: white;
            text-align: center;
            padding: 5rem 0;
        }

        .hero h1 {
            font-size: 2.5rem;
            margin-bottom: 1rem;
        }

        .hero p {
            font-size: 1.2rem;
            max-width: 800px;
            margin: 0 auto;
        }

        .contact-section {
            padding: 4rem 0;
        }

        .section-title {
            text-align: center;
            margin-bottom: 3rem;
        }

        .section-title h2 {
            font-size: 2.2rem;
            color: var(--primary-color);
            position: relative;
            display: inline-block;
            padding-bottom: 10px;
        }

        .section-title h2::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 50%;
            transform: translateX(-50%);
            width: 80px;
            height: 3px;
            background-color: var(--primary-color);
        }

        .contact-content {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 3rem;
        }

        .contact-form {
            background-color: white;
            padding: 2rem;
            border-radius: 8px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.05);
        }

        .form-group {
            margin-bottom: 1.5rem;
        }

        .form-group label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: 500;
        }

        .form-control {
            width: 100%;
            padding: 0.8rem;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 1rem;
        }

        textarea.form-control {
            resize: vertical;
            min-height: 150px;
        }

        .btn {
            display: inline-block;
            padding: 0.8rem 1.5rem;
            background-color: var(--primary-color);
            color: white;
            text-decoration: none;
            border: none;
            border-radius: 4px;
            font-weight: bold;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        .btn:hover {
            background-color: var(--secondary-color);
        }

        .contact-info {
            background-color: white;
            padding: 2rem;
            border-radius: 8px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.05);
        }

        .contact-info h3 {
            color: var(--primary-color);
            font-size: 1.5rem;
            margin-bottom: 1.5rem;
            position: relative;
            padding-bottom: 10px;
        }

        .contact-info h3::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            width: 50px;
            height: 2px;
            background-color: var(--primary-color);
        }

        .info-item {
            display: flex;
            margin-bottom: 1.5rem;
        }

        .info-icon {
            font-size: 1.5rem;
            color: var(--primary-color);
            margin-right: 1rem;
            min-width: 30px;
            text-align: center;
        }

        .info-text h4 {
            margin-bottom: 0.5rem;
        }

        .map-section {
            padding: 4rem 0;
            background-color: var(--light-color);
        }

        .map-container {
            height: 400px;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.05);
        }

        .map-container iframe {
            width: 100%;
            height: 100%;
            border: 0;
        }

        .hours-section {
            padding: 4rem 0;
        }

        .hours-container {
            background-color: white;
            padding: 2rem;
            border-radius: 8px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.05);
            max-width: 800px;
            margin: 0 auto;
        }

        .hours-title {
            color: var(--primary-color);
            font-size: 1.5rem;
            margin-bottom: 1.5rem;
            text-align: center;
            position: relative;
            padding-bottom: 10px;
            display: inline-block;
        }

        .hours-title::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 50%;
            transform: translateX(-50%);
            width: 50px;
            height: 2px;
            background-color: var(--primary-color);
        }

        .hours-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 2rem;
        }

        .hours-column h4 {
            color: var(--primary-color);
            margin-bottom: 1rem;
            text-align: center;
        }

        .hours-item {
            display: flex;
            justify-content: space-between;
            margin-bottom: 0.5rem;
            padding-bottom: 0.5rem;
            border-bottom: 1px dashed #ddd;
        }

        .emergency-section {
            background-color: var(--primary-color);
            color: white;
            padding: 3rem 0;
            text-align: center;
        }

        .emergency-section h2 {
            font-size: 2rem;
            margin-bottom: 1rem;
        }

        .emergency-section p {
            font-size: 1.2rem;
            margin-bottom: 1.5rem;
            max-width: 800px;
            margin-left: auto;
            margin-right: auto;
        }

        .emergency-phone {
            font-size: 2rem;
            font-weight: bold;
            color: white;
            text-decoration: none;
            display: inline-block;
            padding: 0.5rem 2rem;
            background-color: rgba(255, 255, 255, 0.2);
            border-radius: 50px;
            margin-bottom: 1rem;
        }

        footer {
            background-color: var(--dark-color);
            color: white;
            padding: 3rem 0;
        }

        .footer-content {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 2rem;
        }

        .footer-column h3 {
            font-size: 1.2rem;
            margin-bottom: 1.5rem;
            position: relative;
            padding-bottom: 10px;
        }

        .footer-column h3::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            width: 50px;
            height: 2px;
            background-color: var(--primary-color);
        }

        .footer-column ul {
            list-style: none;
        }

        .footer-column ul li {
            margin-bottom: 0.8rem;
        }

        .footer-column ul li a {
            color: #ccc;
            text-decoration: none;
            transition: color 0.3s;
        }

        .footer-column ul li a:hover {
            color: var(--primary-color);
        }

        .contact-info-footer p {
            margin-bottom: 0.8rem;
            display: flex;
            align-items: center;
        }

        .contact-info-footer i {
            margin-right: 10px;
            color: var(--primary-color);
        }

        .copyright {
            text-align: center;
            padding-top: 2rem;
            margin-top: 2rem;
            border-top: 1px solid #444;
        }

        /* Responsive Design */
        @media (max-width: 992px) {
            .contact-content {
                grid-template-columns: 1fr;
            }
        }

        @media (max-width: 768px) {
            .header-content {
                flex-direction: column;
                text-align: center;
            }

            nav ul {
                margin-top: 1rem;
                justify-content: center;
            }

            nav ul li {
                margin: 0 0.7rem;
            }

            .hero h1 {
                font-size: 2rem;
            }

            .hero p {
                font-size: 1rem;
            }

            .section-title h2 {
                font-size: 1.8rem;
            }

            .hours-grid {
                grid-template-columns: 1fr;
            }
        }

        @media (max-width: 480px) {
            .footer-content {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
        <?php include './back.html';?>

    <section class="hero">
        <div class="container">
            <h1>Contact Us</h1>
            <p>We're here to help. Reach out to us with any questions or to schedule an appointment.</p>
        </div>
    </section>

    <section class="contact-section">
        <div class="container">
            <div class="section-title">
                <h2>Get in Touch</h2>
            </div>
            <div class="contact-content">
                <div class="contact-form">
                    <form action="#" method="POST">
                        <div class="form-group">
                            <label for="name">Full Name</label>
                            <input type="text" id="name" name="name" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <label for="email">Email Address</label>
                            <input type="email" id="email" name="email" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <label for="phone">Phone Number</label>
                            <input type="tel" id="phone" name="phone" class="form-control">
                        </div>
                        <div class="form-group">
                            <label for="department">Department</label>
                            <select id="department" name="department" class="form-control">
                                <option value="">Select Department</option>
                                <option value="general">General Consultation</option>
                                <option value="cardiology">Cardiology</option>
                                <option value="pediatrics">Pediatrics</option>
                                <option value="orthopedics">Orthopedics</option>
                                <option value="neurology">Neurology</option>
                                <option value="ophthalmology">Ophthalmology</option>
                                <option value="dental">Dental Services</option>
                                <option value="other">Other</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="message">Message</label>
                            <textarea id="message" name="message" class="form-control" required></textarea>
                        </div>
                        <button type="submit" class="btn">Send Message</button>
                    </form>
                </div>
                <div class="contact-info">
                    <h3>Contact Information</h3>
                    <div class="info-item">
                        <div class="info-icon">📍</div>
                        <div class="info-text">
                            <h4>Address</h4>
                            <p>123 Medical Center Drive<br>Healthcare City, HC 12345</p>
                        </div>
                    </div>
                    <div class="info-item">
                        <div class="info-icon">📞</div>
                        <div class="info-text">
                            <h4>Phone</h4>
                            <p>Main: +1 (555) 123-4567<br>Appointments: +1 (555) 987-6543</p>
                        </div>
                    </div>
                    <div class="info-item">
                        <div class="info-icon">✉️</div>
                        <div class="info-text">
                            <h4>Email</h4>
                            <p>info@medicareOPD.com<br>appointments@medicareOPD.com</p>
                        </div>
                    </div>
                    <div class="info-item">
                        <div class="info-icon">⏰</div>
                        <div class="info-text">
                            <h4>Hours</h4>
                            <p>Monday - Friday: 8:00 AM - 8:00 PM<br>Saturday: 9:00 AM - 5:00 PM<br>Sunday: Closed</p>
                        </div>
                    </div>
                    <div class="info-item">
                        <div class="info-icon">🚑</div>
                        <div class="info-text">
                            <h4>Emergency</h4>
                            <p>For emergencies, please call our 24/7 hotline:<br>+1 (555) 911-0000</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="map-section">
        <div class="container">
            <div class="section-title">
                <h2>Our Location</h2>
            </div>
            <div class="map-container">
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3022.215573036935!2d-73.98784492426285!3d40.75798657138946!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89c25855c6480299%3A0x55194ec5a1ae072e!2sTimes%20Square!5e0!3m2!1sen!2sus!4v1710000000000!5m2!1sen!2sus" allowfullscreen="" loading="lazy"></iframe>
            </div>
        </div>
    </section>

    <section class="hours-section">
        <div class="container">
            <div class="section-title">
                <h2>Operating Hours</h2>
            </div>
            <div class="hours-container">
                <div class="hours-grid">
                    <div class="hours-column">
                        <h4>General OPD</h4>
                        <div class="hours-item">
                            <span>Monday - Friday</span>
                            <span>8:00 AM - 8:00 PM</span>
                        </div>
                        <div class="hours-item">
                            <span>Saturday</span>
                            <span>9:00 AM - 5:00 PM</span>
                        </div>
                        <div class="hours-item">
                            <span>Sunday</span>
                            <span>Closed</span>
                        </div>
                    </div>
                    <div class="hours-column">
                        <h4>Specialized Departments</h4>
                        <div class="hours-item">
                            <span>Cardiology</span>
                            <span>9:00 AM - 4:00 PM</span>
                        </div>
                        <div class="hours-item">
                            <span>Pediatrics</span>
                            <span>8:00 AM - 6:00 PM</span>
                        </div>
                        <div class="hours-item">
                            <span>Orthopedics</span>
                            <span>10:00 AM - 5:00 PM</span>
                        </div>
                    </div>
                    <div class="hours-column">
                        <h4>Laboratory</h4>
                        <div class="hours-item">
                            <span>Monday - Friday</span>
                            <span>7:00 AM - 7:00 PM</span>
                        </div>
                        <div class="hours-item">
                            <span>Saturday</span>
                            <span>7:00 AM - 3:00 PM</span>
                        </div>
                        <div class="hours-item">
                            <span>Sunday</span>
                            <span>Closed</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="emergency-section">
        <div class="container">
            <h2>Emergency Services</h2>
            <p>For medical emergencies requiring immediate attention, please call our 24/7 emergency hotline or visit the nearest emergency room.</p>
            <a href="tel:+15559110000" class="emergency-phone">+1 (555) 911-0000</a>
            <p>Our emergency response team is available 24 hours a day, 7 days a week, including holidays.</p>
        </div>
    </section>

    <footer>
        <div class="container">
            <div class="footer-content">
                <div class="footer-column">
                    <h3>MediCare OPD</h3>
                    <p>Providing quality healthcare services with compassion and excellence since 2005.</p>
                </div>
                <div class="footer-column">
                    <h3>Quick Links</h3>
                    <ul>
                        <li><a href="../index.php">Home</a></li>
                        <li><a href="./service.html">Services</a></li>
                        <li><a href="./about.html">About Us</a></li>
                        <li><a href="./contact.html">Contact</a></li>
                    </ul>
                </div>
                <div class="footer-column">
                    <h3>Our Services</h3>
                    <ul>
                        <li><a href="#">General Consultation</a></li>
                        <li><a href="#">Laboratory Services</a></li>
                        <li><a href="#">Cardiology</a></li>
                        <li><a href="#">Pediatric Care</a></li>
                    </ul>
                </div>
                <div class="footer-column contact-info-footer">
                    <h3>Contact Us</h3>
                    <p><i>📍</i> 123 Medical Center Drive, Healthcare City</p>
                    <p><i>📞</i> +1 (555) 123-4567</p>
                    <p><i>✉️</i> info@medicareOPD.com</p>
                </div>
            </div>
            <div class="copyright">
                <p>&copy; 2025 MediCare OPD. All Rights Reserved.</p>
            </div>
        </div>
    </footer>
</body>
</html>