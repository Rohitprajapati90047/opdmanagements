<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Gallery | OPD Management System</title>
  <style>
    /* Reset some default styles */
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }

    body {
      font-family: 'Segoe UI', sans-serif;
      background-color: #f4f6f8;
      color: #333;
    }

    header {
      background-color:rgb(17, 151, 178);
      color: white;
      padding: 15px 20px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      flex-wrap: wrap;
    }

    header h1 {
      font-size: 20px;
      margin-bottom: 10px;
    }

    nav {
      display: flex;
      flex-wrap: wrap;
    }

    nav a {
      color: white;
      text-decoration: none;
      margin: 5px 10px;
      font-weight: bold;
    }

    nav a.active,
    nav a:hover {
      text-decoration: underline;
    }

    .gallery-section {
      padding: 30px 15px;
      text-align: center;
    }

    .gallery-section h2 {
      font-size: 26px;
      margin-bottom: 25px;
    }

    .gallery-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
      gap: 20px;
      max-width: 1200px;
      margin: 0 auto;
    }

    .gallery-item {
      background-color: white;
      border-radius: 8px;
      box-shadow: 0 2px 10px rgba(0, 0, 0, 0.08);
      overflow: hidden;
      transition: transform 0.3s ease;
    }

    .gallery-item:hover {
      transform: scale(1.02);
    }

    .gallery-item img {
      width: 100%;
      height: 180px;
      object-fit: cover;
    }

    .gallery-item p {
      padding: 10px;
      font-size: 15px;
      background-color: #fafafa;
    }

    footer {
      background-color:rgb(28, 159, 192);
      color: white;
      text-align: center;
      padding: 15px 10px;
      margin-top: 40px;
      font-size: 14px;
    }

    /* Media Queries for Extra Responsiveness */
    @media (max-width: 600px) {
      header {
        flex-direction: column;
        align-items: flex-start;
      }

      header h1 {
        font-size: 18px;
      }

      nav {
        flex-direction: column;
        align-items: flex-start;
      }

      nav a {
        margin: 5px 0;
      }

      .gallery-section h2 {
        font-size: 22px;
      }

      .gallery-item img {
        height: 160px;
      }

      footer {
        font-size: 13px;
      }
    }
  </style>
</head>
<body>

    
    <?php include './back.html'; ?>
    <h1>OPD Management System</h1>

  <section class="gallery-section">
    <h2>Our Facilities & Team</h2>
    <div class="gallery-grid">
      <div class="gallery-item">
        <img src="/newOPD_project_v/asset/img/blog/blog_3.jpg" alt="Doctors Team" />
        <p>Our Expert Doctors</p>
      </div>
      <div class="gallery-item">
        <img src="/newOPD_project_v/asset/img/blog/bed.png" alt="Waiting Area" />
        <p>Spacious Waiting Area</p>
      </div>
      <div class="gallery-item">
        <img src="/newOPD_project_v/asset/img/blog/blog_1.jpg" alt="Examination Room" />
        <p>Modern Exam Rooms</p>
      </div>
      <div class="gallery-item">
        <img src="/newOPD_project_v/asset/img/blog/blog_2.jpg" alt="Reception" />
        <p>Friendly Reception Staff</p>
      </div>
      <div class="gallery-item">
        <img src="/newOPD_project_v/asset/img/bg_image_1.jpg" alt="Pharmacy" />
        <p>In-house Pharmacy</p>
      </div>
      <div class="gallery-item">
        <img src="/newOPD_project_v/asset/img/blog/blog_4.jpg" alt="Lab" />
        <p>Advanced Lab Facilities</p>
      </div>
    </div>
  </section>

  <footer>
    <p>&copy; 2025 OPD Management System. All rights reserved.</p>
  </footer>

</body>
</html>
