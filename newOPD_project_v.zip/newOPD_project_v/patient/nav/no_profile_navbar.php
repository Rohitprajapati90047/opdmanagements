<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Responsive Navbar</title>
    <style>
        /* Base Styles for Navbar */
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        .navbar {
            background-color: rgb(21, 207, 224);
            padding: 10px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            position: relative;
        }

        .navbar ul {
            list-style-type: none;
            padding: 0;
            margin: 0;
            display: flex;
        }

        .navbar ul li {
            margin-right: 20px;
        }

        .navbar ul li a {
            color: white;
            text-decoration: none;
            font-size: 16px;
            padding: 8px;
            transition: background-color 0.3s;
        }

        .navbar ul li a:hover {
            background-color:rgba(47, 76, 79, 0.39);
            border-radius: 4px;
        }

        .profile {
            color: white;
            font-size: 14px;
        }

        .profile a {
            color: white;
            text-decoration: none;
            margin-left: 10px;
        }

        .profile a.logout-btn {
            background-color: #e74c3c;
            padding: 5px 10px;
            border-radius: 4px;
        }

        .profile a.logout-btn:hover {
            background-color: #c0392b;
        }

        /* Hamburger Menu for Mobile */
        .navbar .menu-toggle {
            display: none;
            font-size: 30px;
            color: white;
            cursor: pointer;
        }

        /* Media Queries for Responsiveness */
        @media (max-width: 768px) {
            .navbar ul {
                display: none;
                width: 100%;
                flex-direction: column;
                background-color: #333;
                position: absolute;
                top: 60px;
                left: 0;
                padding: 10px;
            }

            .navbar ul li {
                margin-right: 0;
                text-align: center;
                padding: 10px;
                border-bottom: 1px solid #444;
            }

            .navbar ul li a {
                padding: 12px;
                font-size: 18px;
                display: block;
            }

            .navbar .menu-toggle {
                display: block;
            }

            .navbar.active ul {
                display: flex;
            }

            .navbar .profile {
                text-align: center;
                margin-top: 10px;
            }
        }
    </style>
</head>
<body>

<div class="navbar">
    <div class="menu-toggle" onclick="toggleMenu()">☰</div>
    <ul>
        <li><a href="dashboard.php">Home</a></li>
        <li><a href="../dashboard.php">Dashboard</a></li>
        <li><a href="#">About Us</a></li>    
        <li><a href="#">Gallery</a></li>
        <li><a href="#">Contact Us</a></li>
    </ul>
    <div class="profile">
        <a class="logout-btn" href="../../index.php">Logout</a>
    </div>
</div>

<script>
    // Toggle menu for mobile
    function toggleMenu() {
        const navbar = document.querySelector('.navbar');
        navbar.classList.toggle('active');
    }
</script>

</body>
</html>
