<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: ../login.php");
    exit();
}

$host = "localhost";
$user = "root";
$password = "";
$database = "opd_management";
$conn = mysqli_connect($host, $user, $password, $database);

$username = $_SESSION['username'];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $phone = $_POST['phone'];
    $address = $_POST['address'];
    
    $updateQuery = "UPDATE patient SET phone='$phone', address='$address' WHERE username='$username'";
    
    if (mysqli_query($conn, $updateQuery)) {
        echo "<script>alert('Profile Updated!'); window.location.href='view_profile.php';</script>";
    } else {
        echo "<script>alert('Update Failed!');</script>";
    }
}

$query = "SELECT * FROM patient WHERE username='$username'";
$result = mysqli_query($conn, $query);
$patient = mysqli_fetch_assoc($result);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile</title>
    <link rel="stylesheet" href="../patient_style/dashboard_style.css">
    <style>
        /* Base Styles */
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        .profile-container {
            background-color: white;
            padding: 20px;
            border-radius: 8px;
            max-width: 800px;
            margin: 40px auto;
            box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);
        }

        .profile-container h2 {
            text-align: center;
            margin-bottom: 20px;
        }

        .profile-container label {
            font-weight: bold;
            display: block;
            margin-top: 10px;
        }

        .profile-container input[type="text"] {
            width: 100%;
            padding: 10px;
            margin: 8px 0;
            border: 1px solid #ddd;
            border-radius: 4px;
            box-sizing: border-box;
        }

        .profile-container button {
            width: 100%;
            padding: 12px;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 1rem;
            margin-top: 20px;
        }

        .profile-container button:hover {
            background-color: #45a049;
        }

        /* Media Queries for Responsiveness */
        @media (max-width: 768px) {
            .profile-container {
                padding: 15px;
                margin: 20px;
            }

            .profile-container label {
                font-size: 14px;
            }

            .profile-container input[type="text"] {
                padding: 8px;
            }

            .profile-container button {
                padding: 10px;
                font-size: 0.9rem;
            }
        }

        @media (max-width: 480px) {
            .profile-container {
                margin: 10px;
            }

            .profile-container h2 {
                font-size: 1.5rem;
            }

            .profile-container label {
                font-size: 13px;
            }

            .profile-container input[type="text"] {
                padding: 7px;
            }

            .profile-container button {
                padding: 8px;
                font-size: 0.85rem;
            }
        }
    </style>
</head>
<body>


    <div class="profile-container">
        <h2>My Profile</h2>
        <form method="POST">
            <label>First Name:</label>
            <input type="text" value="<?= $patient['fname']; ?>" readonly>

            <label>Last Name:</label>
            <input type="text" value="<?= $patient['lname']; ?>" readonly>

            <label>Username:</label>
            <input type="text" value="<?= $patient['username']; ?>" readonly>

            <label>Phone:</label>
            <input type="text" name="phone" value="<?= $patient['phone']; ?>" required>

            <label>Address:</label>
            <input type="text" name="address" value="<?= $patient['address']; ?>" required>

            <button type="submit">Update Profile</button>
            <button type="button" onclick="window.location.href='../dashboard.php';" 
           style="background-color: red; color: white; border: none; padding: 10px 20px; border-radius: 5px; cursor: pointer;">
           Cancel
          </button>
        </form>
    </div>
</body>
</html>
