<?php
// dashboard.php
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Responsive OPD Page</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      margin: 0;
      padding: 0;
    }

    header, footer {
      background-color: #004080;
      color: white;
      text-align: center;
      padding: 1rem;
    }

    nav {
      margin-top: 0.5rem;
    }

    nav a {
      margin: 0 1rem;
      color: white;
      text-decoration: none;
    }

    .container {
      padding: 20px;
    }

    @media (max-width: 600px) {
      nav a {
        display: block;
        margin: 10px 0;
      }
    }
  </style>
</head>
<body>

  <!-- Header -->
  <?php include '../patient/nav/back.html'; ?>
  <header>
    <h1>Welcome to OPD System</h1>
    
</header>
  <!-- Main Content -->
  <div class="container">
    <div class="work-box">
      <h2>🚧 Feature Under Development</h2>
      <p>This section is currently under construction.</p>
      <p>We’re working hard to bring this feature to life soon. Stay tuned!</p>
    </div>
  </div>

  <footer>
    <p>&copy; 2025 OPD Project. All rights reserved.</p>
  </footer>

</body>
</html>
