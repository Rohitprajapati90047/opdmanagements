<?php 
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: ./login.php");
    exit();
}

$host = "localhost";
$user = "root";
$password = "";
$database = "opd_management";
$conn = mysqli_connect($host, $user, $password, $database);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$username = $_SESSION['username'];

// Modified query to fetch token based on both visit_date and reason
$query = "
    SELECT 
        rc.patient_name, 
        rc.visit_date, 
        rc.reason, 
        rc.disease_type, 
        rc.opd_room,
        (SELECT t.token_number 
         FROM tokens t 
         WHERE t.username = p.username 
         AND t.visit_date = rc.visit_date 
         AND t.reason = rc.reason LIMIT 1) AS token_number
    FROM renew_case rc
    JOIN patient p ON CONCAT(p.fname, ' ', p.lname) = rc.patient_name 
    WHERE p.username = ?
    ORDER BY rc.visit_date DESC
";

$stmt = mysqli_prepare($conn, $query);
if (!$stmt) {
    die("Statement preparation failed: " . mysqli_error($conn));
}

mysqli_stmt_bind_param($stmt, "s", $username);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
if (!$result) {
    die("Query execution failed: " . mysqli_error($conn));
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Patient Report</title>
    <link rel="stylesheet" href="./patient_style/patient_report.css">
    <style>
        body {
            font-family: Arial, sans-serif;
        }
        .report-container {
            max-width: 90%;
            margin: 30px auto;
            padding: 20px;
            background: #f4f9f4;
            border: 1px solid #ccc;
            border-radius: 10px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            background: white;
        }
        table th, table td {
            padding: 12px;
            border: 1px solid #ddd;
            text-align: center;
        }
        table th {
            background-color: #4CAF50;
            color: white;
        }
        h2 {
            text-align: center;
            color: #333;
        }
        .not-assigned {
            color: gray;
        }
    </style>
</head>
<body>
<?php include '../patient/nav/back.html'; ?>
    <div class="report-container">
        <h2>Patient Report</h2>
        <table>
            <thead>
                <tr>
                    <th>Patient Name</th>
                    <th>Visit Date</th>
                    <th>Reason</th>
                    <th>Disease Type</th>
                    <th>OPD Room</th>
                    <th>Token Number</th>
                </tr>
            </thead>
            <tbody>
                <?php if (mysqli_num_rows($result) > 0): ?>
                    <?php while ($row = mysqli_fetch_assoc($result)): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($row['patient_name']); ?></td>
                            <td><?php echo htmlspecialchars($row['visit_date']); ?></td>
                            <td><?php echo htmlspecialchars($row['reason']); ?></td>
                            <td><?php echo htmlspecialchars($row['disease_type']); ?></td>
                            <td><?php echo htmlspecialchars($row['opd_room']); ?></td>
                            <td>
                                <?php 
                                    echo isset($row['token_number']) 
                                        ? htmlspecialchars($row['token_number']) 
                                        : '<span class="not-assigned">Not Assigned</span>';
                                ?>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="6">No records found.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
<?php include '../footer.php'; ?>
</body>
</html>

<?php
// Clean up resources
mysqli_stmt_close($stmt);
mysqli_close($conn);
?>
