<?php
// Include the database connection file
require_once('../db_connect.php');

// Fetch operation information from the database
$sql = "SELECT o.operation_id, p.fname AS patient_fname, p.lname AS patient_lname, d.name AS doctor_name, o.operation_date, o.operation_type, o.notes
        FROM operations o
        JOIN patient p ON o.patient_id = p.patient_id
        JOIN doctors d ON o.doctor_id = d.id";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Operation Information</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>
        /* General Styles */
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f9f9f9;
            margin: 0;
            padding: 0;
            color: #333;
        }

        h1 {
            text-align: center;
            font-size: 30px;
            margin: 20px 0;
            color: #333;
        }

        .operation-table {
            width: 90%;
            margin: 30px auto;
            overflow-x: auto;
            border-radius: 8px;
            background-color: #fff;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            padding: 20px;
            border: 1px solid #ddd;
        }

        /* Table Styles */
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th, td {
            padding: 15px 20px;
            text-align: left;
            border-bottom: 1px solid #ddd;
            vertical-align: middle;
        }

        th {
            background-color: #4CAF50;
            color: white;
            font-weight: 600;
            font-size: 16px;
        }

        td {
            font-size: 14px;
            color: #555;
        }

        /* Hover effect for rows */
        tr:hover {
            background-color: #f1f1f1;
        }

        /* Responsive Styles */
        @media (max-width: 768px) {
            .operation-table {
                width: 100%;
                padding: 10px;
            }

            table {
                font-size: 12px;
            }

            th, td {
                padding: 12px;
            }

            h1 {
                font-size: 24px;
            }
        }

        /* Mobile view for tables */
        @media (max-width: 480px) {
            table {
                display: block;
                width: 100%;
                overflow-x: auto;
                -webkit-overflow-scrolling: touch;
            }

            th, td {
                display: block;
                text-align: right;
                width: 100%;
                padding: 15px;
                border-bottom: 1px solid #ddd;
            }

            td::before {
                content: attr(data-label);
                font-weight: bold;
                display: inline-block;
                width: 40%;
                margin-right: 10px;
            }

            tr {
                display: block;
                margin-bottom: 1rem;
            }

            tr:hover {
                background-color: transparent;
            }
        }

        /* Empty data row styling */
        .empty-row {
            text-align: center;
            color: #888;
            font-size: 16px;
        }

        /* Table Row Even & Odd Styling for Better Visibility */
        tr:nth-child(even) {
            background-color: #f9f9f9;
        }

    </style>
</head>
<body>
<?php include './nav/back.html'; ?>
    <div class="operation-table">
        <h1>Operation Information</h1>
        <table>
            <thead>
                <tr>
                    <th>Operation ID</th>
                    <th>Patient Name</th>
                    <th>Doctor Name</th>
                    <th>Operation Date</th>
                    <th>Operation Type</th>
                    <th>Notes</th>
                </tr>
            </thead>
            <tbody>
                <?php
                if ($result && $result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        $patient_name = $row['patient_fname'] . ' ' . $row['patient_lname'];
                        echo "<tr>";
                        echo "<td>{$row['operation_id']}</td>";
                        echo "<td data-label='Patient Name'>{$patient_name}</td>";
                        echo "<td data-label='Doctor Name'>{$row['doctor_name']}</td>";
                        echo "<td data-label='Operation Date'>{$row['operation_date']}</td>";
                        echo "<td data-label='Operation Type'>{$row['operation_type']}</td>";
                        echo "<td data-label='Notes'>{$row['notes']}</td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr class='empty-row'><td colspan='6'>No operations found.</td></tr>";
                }
                ?>
            </tbody>
        </table>
    </div>
    <?php include '../footer.php'; ?>
</body>
</html>
                