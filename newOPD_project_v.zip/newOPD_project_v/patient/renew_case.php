<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

$host = "localhost";
$user = "root";
$password = "";
$database = "opd_management";
$conn = mysqli_connect($host, $user, $password, $database);

// Check if connection was successful
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$username = $_SESSION['username'];
$query = "SELECT fname, lname FROM patient WHERE username = ?";
$stmt = mysqli_prepare($conn, $query);
if ($stmt) {
    mysqli_stmt_bind_param($stmt, "s", $username);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $patient = mysqli_fetch_assoc($result);
    mysqli_stmt_close($stmt);
} else {
    die("Error preparing statement: " . mysqli_error($conn));
}

// Combine fname and lname
$patient_name = isset($patient['fname']) && isset($patient['lname']) ? htmlspecialchars($patient['fname'] . ' ' . $patient['lname']) : 'Unknown Patient';

// Get current date
$current_date = date('Y-m-d');
mysqli_close($conn);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Renew Case Paper</title>
    <link rel="stylesheet" href="./patient_style/renew_case_style.css">
    <script>
        function updateOPDRoom() {
            const disease_type = document.getElementById('disease_type').value;
            let opdRoom = '';
            switch (disease_type) {
                case 'SKIN':
                    opdRoom = '20';
                    break;
                case 'ENT':
                    opdRoom = '21';
                    break;
                case 'FEVER':
                    opdRoom = '1';
                    break;
                case 'Teeth':
                    opdRoom = '21';
                    break;
                case 'sugar':
                    opdRoom = '15';
                    break;
                case 'Thyroid':
                    opdRoom = '11';
                    break;
                default:
                    opdRoom = '';
            }
            document.getElementById('opd_room').value = opdRoom;
        }

        // function validateTime() {
        //     const now = new Date();
        //     const currentHour = now.getHours();
        //     const currentMinutes = now.getMinutes();
        //     const startHour = 8;
        //     const endHour = 11;
        //     const endMinutes = 30;

        //     if (currentHour < startHour || (currentHour === endHour && currentMinutes > endMinutes) || currentHour > endHour) {
        //         alert("You can only renew the case paper between 8 AM and 11:30 AM.");
        //         return false;
        //     }
        //     return true;
        // }
    </script>
</head>
<body>
    <div class="renew-case-container">
        <h2>APPOINMENT</h2>
        <form action="process_renew_case.php" method="POST" onsubmit="return validateTime()">
            <div class="form-group">
                <label>Patient Name:</label>
                <input type="text" name="patient_name" value="<?php echo $patient_name; ?>" readonly>
            </div>
            <div class="form-group">
                <label>Username:</label>
                <input type="text" name="username" value="<?php echo $username; ?>" readonly>
            </div>
            <div class="form-group">
                <label>Visit Date:</label>
                <input type="date" name="visit_date" value="<?php echo $current_date; ?>" required>
            </div>
            <div class="form-group">
                <label>Reason for Visit:</label>
                <textarea name="reason" placeholder="Describe your reason for the visit..." required></textarea>
            </div>
            <div class="form-group">
                <label>Type of Disease:</label>
                <select name="disease_type" id="disease_type" onchange="updateOPDRoom()" required>
                    <option value="">Select Disease</option>
                    <option value="SKIN">🧴 SKIN</option>
                    <option value="ENT">👂 EAR</option>
                    <option value="FEVER">👨‍⚕️ FEVER</option>
                    <option value="FEVER">👨‍⚕️ COLD</option>
                    <option value="Teeth">🦷 TEETH</option>
                    <option value="sugar">🩺 DIABETES</option>
                    <option value="ENT">👃 NOSE</option>
                    <option value="Bone">🦴 FRACTURE</option>
                    <option value="ENT">👁️ EYE</option>
                    <option value="Thyroid">🫁 THYROID</option>
                    <!-- Additional disease typs can be added here -->
                </select>
            </div>
            <div class="form-group">
                <label>OPD Room Number:</label>
                <input type="text" id="opd_room" name="opd_room" readonly>
            </div>
            <div class="form-group">
                <label>Payment Amount:</label>
                <input type="text" name="payment_amount" value="10" readonly>
            </div>
            <div class="form-group">
                <label>Payment Validity:</label>
                <input type="text" name="payment_validity" value="7 days" readonly>
            </div>
            <button type="submit" class="submit-btn">Submit</button>
            <a href="dashboard.php" class="cancel-btn">Cancel</a>
        </form>
    </div>
    
</body>
</html>
