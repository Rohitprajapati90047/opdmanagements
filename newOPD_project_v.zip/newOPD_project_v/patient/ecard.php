<?php
include '../db_connect.php';
session_start();

if (!isset($_SESSION['username'])) {
    echo "User not logged in.";
    exit;
}

$username = $_SESSION['username'];

// Improved query with error handling
$result = $conn->query("SELECT * FROM patient WHERE username='$username'");

if (!$result) {
    echo "Error: " . $conn->error;
    exit;
}

$patient = $result->fetch_assoc();

if (!$patient) {
    echo "No patient data found for the given username.";
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>User E-Card</title>
    <!-- ✅ Updated html2canvas version -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js"></script>

    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f5f5f5;
        }

        .ecard {
            background-color: #fff;
            width: 350px;
            padding: 20px;
            border-radius: 15px;
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.3);
            text-align: center;
            transform: perspective(1000px) rotateX(3deg) rotateY(-5deg);
            transition: transform 0.3s ease;
            margin: 20px auto;
        }

        .ecard:hover {
            transform: perspective(1000px) rotateX(0deg) rotateY(0deg) scale(1.03);
        }

        h2 {
            margin-bottom: 20px;
            font-size: 24px;
            color: #333;
        }

        p {
            margin: 8px 0;
            font-size: 18px;
            color: #555;
        }

        #dd {
    margin-top: 20px;
    padding: 10px 20px;
    background-color: #3498db;
    color: white;
    border: none;
    border-radius: 8px;
    cursor: pointer;
    transition: background-color 0.3s;
    margin: 20px auto;
    display: block;
    margin-left: 20px;
        }


        button:hover {
            background-color: #2980b9;
        }
    </style>
</head>
<body>
<?php include '../patient/nav/back.html'; ?>

<div class="ecard" id="ecard">
    <h2>Health Registration Card</h2>
    <p><b>UHID:</b> 3110000<?= $patient['patient_id'] ?? 'N/A' ?></p>
    <p><b>Name:</b> <?= ($patient['fname'] ?? '') . " " . ($patient['lname'] ?? '') ?></p>
    <p><b>Age:</b> <?= isset($patient['dob']) ? (date("Y") - date("Y", strtotime($patient['dob']))) : 'N/A' ?></p>
    <p><b>Gender:</b> <?= $patient['gender'] ?? 'N/A' ?></p>
    <p><b>Address:</b> <?= $patient['address'] ?? 'N/A' ?></p>
    <p><b>Contact:</b> <?= $patient['phone'] ?? 'N/A' ?></p>
</div>

<div class="download">
    <button id="dd" onclick="downloadCard()">Download e-Card</button>
</div>

<script>
    function downloadCard() {
        html2canvas(document.getElementById("ecard")).then(function(canvas) {
            let link = document.createElement("a");
            link.href = canvas.toDataURL("image/png");
            link.download = "e-card.png";
            link.click();
        });
    }
</script>

<?php include '../footer.php'; ?>   
</body>
</html>
