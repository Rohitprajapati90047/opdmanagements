    <?php
    session_start();
    include('../db_connect.php'); // Include your database connection file

    // Check if the user is logged in
    if (!isset($_SESSION['username'])) {
        header('Location: ./login.php');
        exit();
    }

    $username = $_SESSION['username'];
    $selected_date = isset($_POST['prescription_date']) ? $_POST['prescription_date'] : date('Y-m-d');

    // Fetch disease and medicine information from the database
 $query = "SELECT p.*, pm.medicine_name, pm.dosage, pm.duration, d.name as doctor_name, d.degree as doctor_degree
            FROM prescriptions p
            JOIN prescription_medicines pm ON p.id = pm.prescription_id
            JOIN patient pat ON p.patient_id = pat.patient_id
            JOIN doctors d ON p.doctor_id = d.id
            WHERE pat.username = ? AND DATE(p.created_at) = ?";
    $stmt = $conn->prepare($query);
    if ($stmt === false) {
        die('Prepare failed: ' . htmlspecialchars($conn->error));
    }
    $stmt->bind_param("ss", $username, $selected_date);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result === false) {
        die('Execute failed: ' . htmlspecialchars($stmt->error));
    }

    // Fetch the doctor's name
    $doctor_name = '';
    $doctor_degree = '';
    if ($row = $result->fetch_assoc()) {
        $doctor_name = $row['doctor_name'];
        $doctor_degree = $row['doctor_degree'];
        $result->data_seek(0); // Reset result pointer to the beginning
    }
    ?>


    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Disease and Medicine</title>
        
        <link rel="stylesheet" type="text/css" href="styles/disease_medicine.css"> <!-- Link to your CSS file -->
        <script>
            function printCasePaper() {
                var printContents = document.getElementById('casePaper').innerHTML;
                var originalContents = document.body.innerHTML;

                document.body.innerHTML = printContents;
                window.print();
                document.body.innerHTML = originalContents;
            }
        </script>
    </head>
    <body>
    <?php include '../patient/nav/back.html'; ?>

        <h1>Disease and Medicine Information</h1>
        
    <form method="POST" action="">
        <label for="prescription_date">Select Date:</label>
        <input type="date" id="prescription_date" name="prescription_date" value="<?php echo htmlspecialchars($selected_date); ?>" required>
        <button type="submit" style="background-color:#0F0A8E; color: white; border-radius:5px; padding: 5px 20px; font-size: 14px; cursor: pointer;">View</button>
    </form>
    <div id="casePaper" style="position: relative; width: 100%; max-width: 800px; margin: auto;">
        <!-- <img src="./asset/pho.jpg" alt="Case Paper Template" style="width: 100%; height: 100%; position: absolute; top: 0; left: 0; z-index: 1;"> -->
        <div style="position: relative; z-index: 2; padding: 40px; color: black;">

        
            <!-- Hospital Information -->
            <div style="text-align: center; margin-bottom: 20px;">
                <h2>Government of Maharashtra</h2>
                <h3>Rajawadi Hospital</h3>
                <p>Near Ghatkopar West, New Light Road, Mumbai</p>
            </div>

            <?php if ($result->num_rows > 0): ?>
                <!-- Disease Information -->
                <p style="margin-bottom: 10px;"><strong>Disease:</strong></p>
                <?php while ($row = $result->fetch_assoc()): ?>
                    <p style="margin-left: 20px;"><?php echo htmlspecialchars($row['disease']); ?></p>
                <?php endwhile; ?>

                <!-- Medicine Information -->
                <p style="margin-top: 20px;"><strong>Medicine:</strong></p>
                <?php 
                $result->data_seek(0); // Reset pointer to the beginning
                while ($row = $result->fetch_assoc()): ?>
                    <p style="margin-left: 20px;">
                        <?php echo htmlspecialchars($row['medicine_name']); ?> - 
                        <span>Dose: <?php echo htmlspecialchars($row['dosage']); ?></span> - 
                        <span>Duration: <?php echo htmlspecialchars($row['duration']); ?></span>
                    </p>
                <?php endwhile; ?>

                <!-- Doctor and Date Information -->
                <div style="margin-top: 40px;">
                    <p>Date: <?php echo htmlspecialchars($selected_date); ?></p>
                    <p>Doctor Name: <?php echo htmlspecialchars($doctor_name); ?></p>
                    <p>Doctor Degree: <?php echo htmlspecialchars($doctor_degree); ?></p>

                </div>
            <?php else: ?>
                <!-- No Prescription Message -->
                <div style="text-align: center; margin-top: 50px;">
                    <p style="color: red; font-weight: bold;">No prescription by doctor. Select another date.</p>
                </div>
            <?php endif; ?>

        </div>
    </div>
    <button style="background-color:#0F0A8E; color: white; border-radius:5px; padding: 5px 20px; font-size: 14px; cursor: pointer; margin-left:8px;" onclick="printCasePaper()">Print Case Paper</button>
    <button type="button" onclick="window.location.href='./dashboard.php';" 
           style="background-color: red; color: white; border: none; padding: 8px 20px; border-radius: 5px; cursor: pointer;">
           Cancel
          </button>
    <?php include '../footer.php'; ?>
    </body>
    </html>

    <?php
    $stmt->close();
    $conn->close();
    ?>
