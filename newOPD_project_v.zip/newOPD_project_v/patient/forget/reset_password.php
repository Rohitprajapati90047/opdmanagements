<?php
session_start();
require_once('../../db_connect.php');

$success_message = "";
$error_message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['reset_password'])) {
    // Securely hash the new password
    $new_password = password_hash($_POST['new_password'], PASSWORD_BCRYPT);
    $email = $_SESSION['email']; // Retrieve email from session

    // Update password query
    $sql = "UPDATE doctors SET password = ? WHERE email = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $new_password, $email);

    if ($stmt->execute()) {
        $success_message = "Password has been reset successfully!";
        session_destroy(); // Destroy session after resetting the password

        // Redirect to doctor dashboard after 5 seconds
        header("refresh:3;url=../doctor_dashboard.php");
    } else {
        $error_message = "Error resetting password. Please try again!";
    }

    $stmt->close(); // Close the prepared statement
    $conn->close(); // Close the database connection
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Reset Password</title>
    <link rel="stylesheet" href="forgot_password.css">
    <style>
        /* Style for green success pop-up */
        .success-popup {
            background-color: #4CAF50; /* Green color */
            color: white;
            padding: 10px;
            position: fixed;
            top: 20px;
            right: 20px;
            border-radius: 5px;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.2);
            display: none; /* Initially hidden */
        }

        /* Style for error message pop-up */
        .error-popup {
            background-color: #f44336; /* Red color */
            color: white;
            padding: 10px;
            position: fixed;
            top: 20px;
            right: 20px;
            border-radius: 5px;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.2);
            display: none; /* Initially hidden */
        }
    </style>
</head>
<body>
    <?php if (!empty($success_message)): ?>
        <div class="success-popup" id="successPopup"><?php echo $success_message; ?></div>
        <script>
            // Show the success pop-up
            document.getElementById('successPopup').style.display = 'block';
            setTimeout(() => {
                document.getElementById('successPopup').style.display = 'none';
            }, 5000); // Hide after 5 seconds
        </script>
    <?php elseif (!empty($error_message)): ?>
        <div class="error-popup" id="errorPopup"><?php echo $error_message; ?></div>
        <script>
            // Show the error pop-up
            document.getElementById('errorPopup').style.display = 'block';
            setTimeout(() => {
                document.getElementById('errorPopup').style.display = 'none';
            }, 5000); // Hide after 5 seconds
        </script>
    <?php endif; ?>

    <form method="POST">
        <h1>Reset Password</h1>
        <label for="new_password">Enter New Password:</label><br>
        <input type="password" name="new_password" id="new_password" required><br><br>
        <button type="submit" name="reset_password">Reset Password</button>
    </form>
</body>
</html>
