<?php
session_start();
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['verify_otp'])) {
    $entered_otp = $_POST['otp'];

    if ($entered_otp == $_SESSION['otp']) {
        header("Location: reset_password.php");
        exit();
    } else {
        $error_message = "Invalid OTP!";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Verify OTP</title>
    <link rel="stylesheet" href="forgot_password.css">

</head>
<body>
    
    <?php if (isset($error_message)): ?>
        <div class="error"><?php echo $error_message; ?></div>
    <?php endif; ?>
    <form method="POST">
    <h1>Verify OTP</h1>
        <label for="otp">Enter OTP:</label><br>
        <input type="number" name="otp" id="otp" required><br><br>
        <button type="submit" name="verify_otp">Verify OTP</button>
    </form>
</body>
</html>