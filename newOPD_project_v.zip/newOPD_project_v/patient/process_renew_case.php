<?php
session_start();

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

// Database connection
$host = "localhost";
$user = "root";
$password = "";
$database = "opd_management";
$conn = mysqli_connect($host, $user, $password, $database);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Get and sanitize form values
$visit_date = filter_var($_POST['visit_date'], FILTER_SANITIZE_STRING);
$username = filter_var($_POST['username'], FILTER_SANITIZE_STRING);
$patient_name = filter_var($_POST['patient_name'], FILTER_SANITIZE_STRING);
$reason = filter_var($_POST['reason'], FILTER_SANITIZE_STRING);
$disease_type = filter_var($_POST['disease_type'], FILTER_SANITIZE_STRING);
$opd_room = filter_var($_POST['opd_room'], FILTER_SANITIZE_STRING);
$payment_amount = filter_var($_POST['payment_amount'], FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION);
$payment_validity = filter_var($_POST['payment_validity'], FILTER_SANITIZE_STRING);

// Validate visit_date format
if (strtotime($visit_date) === false) {
    echo "Invalid visit date format.";
    exit();
}

// Generate unique transaction ID
$transaction_id = uniqid('TXN_');

// Step 1: Get today's token count for the specific disease type
$token_sql = "SELECT COUNT(*) AS today_count FROM tokens WHERE visit_date = ? AND disease_type = ?";
$stmt = mysqli_prepare($conn, $token_sql);
if ($stmt === false) {
    die("Error preparing query: " . mysqli_error($conn));
}
mysqli_stmt_bind_param($stmt, "ss", $visit_date, $disease_type);
if (!mysqli_stmt_execute($stmt)) {
    die("Error executing query: " . mysqli_error($conn));
}
$result = mysqli_stmt_get_result($stmt);
$row = mysqli_fetch_assoc($result);
$today_count = $row['today_count'];
$token_number = $today_count + 1;
mysqli_stmt_close($stmt);

// Step 2: Insert into renew_case table (including payment and transaction_id)
$insert_renew_case = "INSERT INTO renew_case (patient_name, visit_date, reason, disease_type, opd_room, payment_amount, payment_validity, token_number, transaction_id)
                      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
$stmt_renew = mysqli_prepare($conn, $insert_renew_case);
mysqli_stmt_bind_param($stmt_renew, "sssssssss", $patient_name, $visit_date, $reason, $disease_type, $opd_room, $payment_amount, $payment_validity, $token_number, $transaction_id);
if (!mysqli_stmt_execute($stmt_renew)) {
    die("Error executing query: " . mysqli_error($conn));
}
mysqli_stmt_close($stmt_renew);

// Step 3: Insert into tokens table (including transaction_id)
$insert_sql = "INSERT INTO tokens (username, patient_name, visit_date, token_number, reason, disease_type, opd_room, payment_amount, payment_validity, transaction_id)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
$stmt = mysqli_prepare($conn, $insert_sql);
mysqli_stmt_bind_param($stmt, "sssissssss", $username, $patient_name, $visit_date, $token_number, $reason, $disease_type, $opd_room, $payment_amount, $payment_validity, $transaction_id);
$success = mysqli_stmt_execute($stmt);

// Show success or error message
if ($success) {
    echo "<h2>Appointment Confirmed!</h2>";
    echo "<p><strong>Patient Name:</strong> $patient_name</p>";
    echo "<p><strong>Visit Date:</strong> $visit_date</p>";
    echo "<p><strong>Your Token Number:</strong> <span style='font-size:24px;color:green;'>$token_number</span></p>";
    echo "<p><strong>OPD Room:</strong> $opd_room</p>";
    echo "<p><strong>Disease Type:</strong> $disease_type</p>";
    echo "<p><strong>Payment Amount:</strong> $payment_amount</p>";
    echo "<p><strong>Payment Validity:</strong> $payment_validity</p>";
    echo "<p><strong>Transaction ID:</strong> $transaction_id</p>";
    echo "<a href='dashboard.php'>Back to Dashboard</a>";
} else {
    echo "Error saving appointment: " . mysqli_error($conn);
}

mysqli_stmt_close($stmt);
mysqli_close($conn);
?>
