<?php
include '../db_connect.php';
session_start();

if (!isset($_SESSION['username'])) {
    echo "User not logged in.";
    exit;
}

$username = $_SESSION['username'];
$result=$conn->query("SELECT * FROM renew_case WHERE username='$username'");
if(!$result){
    echo "Error: " . $conn->error;
    exit;
}
    ?>

<!DOCTYPE html>
<html>
<head>
    <title>Transaction Details</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            /* padding: 20px; */
        }
        table {
            width: 100%;
            margin: auto;
            border-collapse: collapse;
        }
        th, td {
            padding: 12px;
            text-align: left;
            border: 1px solid #ddd;
        }
        th {
            background-color: #4CAF50;
            color: white;
        }
        tr:hover {
            background-color: #f1f1f1;
        }
        .back-btn {
            background-color: red;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
    </style>
</head>
<body>

<?php include '../patient/nav/back.html'; ?>
<h2 style="text-align: center;">Transaction Details</h2>

<table>
    <tr>
        <th>Patient Name</th>
        <th>Visit Date</th>
        <th>Reason</th>
        <th>Disease Type</th>
        <th>OPD Room</th>
        <th>Amount</th>
        <!-- <th>Valid Till</th> -->
        <th>Transaction ID</th>
    </tr>
    <?php while ($row = $result->fetch_assoc()): ?>
    <tr>
        <td><?php echo htmlspecialchars($row['patient_name']); ?></td>
        <td><?php echo htmlspecialchars($row['visit_date']); ?></td>
        <td><?php echo htmlspecialchars($row['reason']); ?></td>
        <td><?php echo htmlspecialchars($row['disease_type']); ?></td>
        <td><?php echo htmlspecialchars($row['opd_room']); ?></td>
        <td><?php echo htmlspecialchars($row['payment_amount']); ?></td>
        <!-- <td><?php echo htmlspecialchars($row['payment_validity']); ?></td> -->
        <td><?php echo htmlspecialchars($row['transaction_id']); ?></td>
    </tr>
    <?php endwhile; ?>
</table>

<!-- Back Button -->
<!-- <div style="text-align: center; margin-top: 20px;">
    <button onclick="window.location.href='./dashboard.php';" class="back-btn">Back to Dashboard</button>
</div> -->

</body>
</html>

<?php
// Close the database connection
$conn->close();
?>
