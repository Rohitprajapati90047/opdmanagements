<?php
session_start();
include '../db_connect.php';

if (!isset($_SESSION['doctor_id']) || $_SERVER['REQUEST_METHOD'] != 'POST') {
    exit('Invalid request');
}

$username = $_POST['username'];
$doctor_id = $_POST['doctor_id'];
$disease = $_POST['disease'];
$consultation_notes = $_POST['consultation_notes'];
$medicines = $_POST['medicine'];
$dosages = $_POST['dosage'];
$durations = $_POST['duration'];

// Fetch patient_id using username
$patient_query = "SELECT patient_id FROM patient WHERE username = ?";
$patient_stmt = $conn->prepare($patient_query);
$patient_stmt->bind_param("s", $username);
$patient_stmt->execute();
$patient_result = $patient_stmt->get_result();

if ($patient_result->num_rows == 0) {
    exit('Invalid patient username');
}

$patient = $patient_result->fetch_assoc();
$patient_id = $patient['patient_id'];

// Insert prescription
$stmt = $conn->prepare("INSERT INTO prescriptions (patient_id, doctor_id, disease, consultation_notes) VALUES (?, ?, ?, ?)");
$stmt->bind_param("iiss", $patient_id, $doctor_id, $disease, $consultation_notes);
$stmt->execute();
$prescription_id = $stmt->insert_id;

// Insert medicines
for ($i = 0; $i < count($medicines); $i++) {
    $medicine = $medicines[$i];
    $dosage = $dosages[$i];
    $duration = $durations[$i];

    $stmt = $conn->prepare("INSERT INTO prescription_medicines (prescription_id, medicine_name, dosage, duration) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("isss", $prescription_id, $medicine, $dosage, $duration);
    $stmt->execute();
}

header("Location: doctor_dashboard.php");
exit();
?>