<?php
include '../db_connect.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_BCRYPT);
    $phone = $_POST['phone'];
    // $specialization = $_POST['specialization'];
    $license_no = $_POST['license_no'];
    $disease_type = $_POST['disease_type']; // Add new field

    $sql = "INSERT INTO doctors (name, email, password, phone, license_no, disease_type) 
            VALUES ('$name', '$email', '$password', '$phone', '$license_no', '$disease_type')";

    if (mysqli_query($conn, $sql)) {
        echo "Registration successful! <a href='doctor_login.php'>Login here</a>";
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Doctor Registration</title>
    <link rel="stylesheet" href="registerStyle.css">
</head>
<body>
    <form method="post">
        <h2>Doctor Register</h2>
        
        <input type="text" name="name" placeholder="Full Name" required><br>
        <input type="email" name="email" placeholder="Email" required><br>
        <input type="password" name="password" placeholder="Password" required><br>
        <input type="text" name="phone" placeholder="Phone" required><br>
        <input type="text" name="license_no" placeholder="License Number" required><br>
        
        <select name="disease_type" required>
            <option value="">Specialization</option>
            <option value="SKIN">🧴 Dermatologist</option>
            <option value="ENT">👂👃🗣️ ENT (Otolaryngologist)</option>
            <option value="FEVER">👨‍⚕️ General Physician</option>
            <option value="Diabetes">🩺 Endocrinologist</option>
            <option value="Teeth">🦷 General Dentist</option>
            <option value="Bone">🦴 Orthopedic Surgeon / Orthopedist</option>
        </select><br>
        <select name="degree" required>
            <option value="Degree"> Degree </option>
            <option value="MD"> MD </option>
            <option value="MBBS">MBBS</option>
            <option value="DDS"> DDS </option>
            <option value="MS"> MS </option>

        </select>
        <button type="submit">Register</button>
    </form>
</body>
</html>