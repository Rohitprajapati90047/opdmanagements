<?php session_start(); if (!isset($_SESSION['doctor_id'])) {     header("Location: doctor_login.php"); 
        exit(); } include '../db_connect.php';  // Get doctor's disease type and name 
        $doctor_id = $_SESSION['doctor_id']; 
        $doctor_query = $conn->query("SELECT disease_type, name FROM doctors WHERE id = '$doctor_id'");
         $doctor = $doctor_query->fetch_assoc(); 
         $disease_type = $doctor['disease_type']; ?> 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Doctor Dashboard</title>
    <link rel="stylesheet" href="newdoctordashboardstyle.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;600;700&display=swap">
</head>
<body>
    <?php include './nav/navbar.php'; ?>
    
    <div class="container">
        <div class="welcome-section">
            <h2>Welcome, Dr. <?php echo htmlspecialchars($doctor['name']); ?></h2>
            <p>Specialization: <?php echo htmlspecialchars($doctor['disease_type']); ?></p>
        </div>
        
        <h3>Patient List (<?php echo htmlspecialchars($doctor['disease_type']); ?> Department)</h3>
        
        <table class="patient-table">
            <thead>
                <tr>
                    <th>Patient Name</th>
                    <th>Username</th>
                    <th>Visit Date</th>
                    <th>Reason</th>
                    <th>OPD Room</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php
                // Fetch patients from renew_case table whose disease type matches the doctor's specialization
                $result = $conn->query("SELECT patient_name, username, visit_date, reason, opd_room 
                                FROM renew_case 
                                WHERE disease_type = '$disease_type'");
                        
                if ($result->num_rows > 0) {
                    while ($patient = $result->fetch_assoc()) {
                     echo "<tr>
                                <td>" . htmlspecialchars($patient['patient_name']) . "</td>
                                <td>" . htmlspecialchars($patient['username']) . "</td>
                                <td>" . htmlspecialchars($patient['visit_date']) . "</td>
                                <td>" . htmlspecialchars($patient['reason']) . "</td>
                                <td>" . htmlspecialchars($patient['opd_room']) . "</td>
                                <td class='action-buttons'>
                                    <button class='btn btn-primary' onclick='showPrescriptionForm(\"" . $patient['username'] . "\")'>Add Prescription</button>
                                    <button class='btn btn-success' onclick='viewPrescriptions(\"" . $patient['username'] . "\")'>View Prescriptions</button>
                                    <button class='btn btn-warning' onclick='assignOperation(\"" . $patient['username'] . "\")'>Assign Operation</button>
                                    <button class='btn btn-info' onclick='editOperation(\"" . $patient['username'] . "\")'>Edit Operation</button>

                                </td>
                            </tr>";

                    }
                } else {
                    echo "<tr><td colspan='6' class='empty-message'>No patients found in your department.</td></tr>";
                }
                ?>
            </tbody>
        </table>
    </div>
    
    <!-- Prescription Form Modal -->
    <div id="prescriptionModal" class="modal">
        <div class="modal-content">
            <button type="button" class="close-btn" onclick="closeModal()">&times;</button>
            
            <div class="modal-header">
                <h4>Add New Prescription</h4>
            </div>
            
            <div class="modal-body">
                <form id="prescriptionForm" method="post" action="save_prescription.php">
                    <input type="hidden" name="username" id="username">
                    <input type="hidden" name="doctor_id" value="<?php echo $doctor_id; ?>">
                    
                    <div class="form-group">
                        <label for="disease">Disease:</label>
                        <input type="text" id="disease" name="disease" class="form-control" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="consultation_notes">Consultation Notes:</label>
                        <textarea id="consultation_notes" name="consultation_notes" class="form-control" required></textarea>
                    </div>
                    
                    <div class="form-group">
                        <label>Medicines:</label>
                        <div id="medicines">
                            <div class="medicine-entry">
                                <input type="text" name="medicine[]" class="form-control" placeholder="Medicine Name" required>
                                <input type="text" name="dosage[]" class="form-control" placeholder="Dosage" required>
                                <input type="text" name="duration[]" class="form-control" placeholder="Duration" required>
                            </div>
                        </div>
                        <button type="button" class="btn btn-success" onclick="addMedicineField()">Add More Medicine</button>
                    </div>
                    
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" onclick="closeModal()">Cancel</button>
                        <button type="submit" class="btn btn-primary">Save Prescription</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <script>
        function editOperation(username) {
            
                 window.location.href = 'edit_operation.php?username=' + username;
                }


        function assignOperation(username) {
            window.location.href = 'assign_operation.php?username=' + username;
        }
        
        function showPrescriptionForm(username) {
            document.getElementById('username').value = username;
            document.getElementById('prescriptionModal').style.display = 'flex';
            document.body.style.overflow = 'hidden';
        }
        
        function closeModal() {
            document.getElementById('prescriptionModal').style.display = 'none';
            document.body.style.overflow = 'auto';
        }
        
        function addMedicineField() {
            const medicineDiv = document.createElement('div');
            medicineDiv.className = 'medicine-entry';
            medicineDiv.innerHTML = `
                <input type="text" name="medicine[]" class="form-control" placeholder="Medicine Name" required>
                <input type="text" name="dosage[]" class="form-control" placeholder="Dosage" required>
                <input type="text" name="duration[]" class="form-control" placeholder="Duration" required>
            `;
            document.getElementById('medicines').appendChild(medicineDiv);
        }
        
        function viewPrescriptions(username) {
            window.location.href = 'view_prescriptions.php?username=' + username;
        }
        
        // Close modal when clicking outside of it
        window.onclick = function(event) {
            const modal = document.getElementById('prescriptionModal');
            if (event.target == modal) {
                closeModal();
            }
        }
    </script>
</body>
</html>