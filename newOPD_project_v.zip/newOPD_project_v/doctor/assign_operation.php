<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);
require_once('../db_connect.php');

// Check if the doctor is logged in
if (!isset($_SESSION['doctor_id'])) {
    header("Location: ../doctor_login.php");
    exit();
}

$doctor_id = $_SESSION['doctor_id'];

// Get doctor details
$doctor_query = $conn->query("SELECT name FROM doctors WHERE id = '$doctor_id'");
$doctor = $doctor_query->fetch_assoc();
$doctor_name = $doctor['name'];

// Get patient details from URL parameter
$selected_patient_username = isset($_GET['username']) ? $_GET['username'] : '';
$selected_patient = null;
if ($selected_patient_username) {
    $patient_query = $conn->query("SELECT patient_id, fname, lname FROM patient WHERE username = '$selected_patient_username'");
    $selected_patient = $patient_query->fetch_assoc();
    $patient_name = $selected_patient['fname'] . ' ' . $selected_patient['lname'];
}

// Check if updating an existing operation
$operation_id = isset($_GET['operation_id']) ? (int)$_GET['operation_id'] : 0;
$operation = null;
if ($operation_id) {
    $operation_query = $conn->query("SELECT * FROM operations WHERE operation_id = $operation_id");
    $operation = $operation_query->fetch_assoc();
}

// Add or update operation assignment
if (isset($_POST['assign_operation'])) {
    $patient_id = (int)$_POST['patient_id'];
    $operation_date = $_POST['operation_date'];
    $operation_type = $_POST['operation_type'];
    $notes = $_POST['notes'];

    if ($operation_id) {
        // Update existing operation
        $sql = "UPDATE operations SET operation_date = ?, operation_type = ?, notes = ?, doctor_name = ?, patient_name = ? WHERE operation_id = ?";
        $stmt = $conn->prepare($sql);
        if (!$stmt) {
            die("Prepare failed: " . mysqli_error($conn));
        }
        $stmt->bind_param("sssssi", $operation_date, $operation_type, $notes, $doctor_name, $patient_name, $operation_id);
    } else {
        // Insert new operation
        $sql = "INSERT INTO operations (patient_id, doctor_id, operation_date, operation_type, notes, doctor_name, patient_name) VALUES (?, ?, ?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        if (!$stmt) {
            die("Prepare failed: " . mysqli_error($conn));
        }
        $stmt->bind_param("iisssss", $patient_id, $doctor_id, $operation_date, $operation_type, $notes, $doctor_name, $patient_name);
    }

    // if ($stmt->execute()) {
    //     echo "Operation " . ($operation_id ? "updated" : "assigned") . " successfully!<br>";
    // } else {
    //     echo "Error inserting operation: " . $stmt->error . "<br>";
    // }
    $message = '';
$message_type = '';

if ($stmt->execute()) {
    $message = "Operation " . ($operation_id ? "updated" : "assigned") . " successfully!";
    $message_type = 'success';
} else {
    $message = "Error inserting operation: " . $stmt->error;
    $message_type = 'error';
}

}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title><?php echo $operation_id ? "Update" : "Assign"; ?> Operation</title>
    <link rel="stylesheet" href="../dashboard_style.css">
    <link rel="stylesheet" href="assign_operationStyle.css">
</head>
<body>
    <?php include './nav/back.html'; ?>
    <h1><?php echo $operation_id ? "Update" : "Assign"; ?> Operation</h1>
    <?php if (!empty($message)): ?>
    <div class="<?php echo $message_type === 'success' ? 'success-message' : 'error-message'; ?>">
        <?php echo htmlspecialchars($message); ?>
    </div>
<?php endif; ?>

    <form method="POST">
        <input type="hidden" name="operation_id" value="<?php echo htmlspecialchars($operation_id); ?>">
        <label for="patient_id">Patient ID:</label>
        <input type="number" id="patient_id" name="patient_id" value="<?php echo htmlspecialchars($selected_patient ? $selected_patient['patient_id'] : ($operation ? $operation['patient_id'] : '')); ?>" readonly required><br>

        <label for="operation_date">Operation Date:</label>
        <input type="date" id="operation_date" name="operation_date" value="<?php echo htmlspecialchars($operation ? $operation['operation_date'] : ''); ?>" required><br>

        <label for="operation_type">Operation Type:</label>
        <input type="text" id="operation_type" name="operation_type" value="<?php echo htmlspecialchars($operation ? $operation['operation_type'] : ''); ?>" required><br>

        <label for="notes">Notes:</label>
        <textarea id="notes" name="notes" required><?php echo htmlspecialchars($operation ? $operation['notes'] : ''); ?></textarea><br>

        <button type="submit" name="assign_operation"><?php echo $operation_id ? "Update" : "Assign"; ?> Operation</button>
   
    <button style="background-color:red"><a href="./edit_operation.php" style="text-decoration:none;color:white">Edit Operations</a></button>
</form>
</body>
</html>
