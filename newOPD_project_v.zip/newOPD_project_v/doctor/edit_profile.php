<?php
session_start();
if (!isset($_SESSION['doctor_id'])) {
    header("Location: doctor_login.php");
    exit();
}
include '../db_connect.php';

// Get doctor's information
$doctor_id = $_SESSION['doctor_id'];
$doctor_query = $conn->query("SELECT * FROM doctors WHERE id = '$doctor_id'");
$doctor = $doctor_query->fetch_assoc();

// Update doctor's information
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $disease_type = $_POST['disease_type'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $license_no = $_POST['license_no'];
    // $experience = $_POST['experience'];

    $update_query = $conn->prepare("UPDATE doctors SET name = ?, disease_type = ?, email = ?, phone = ?, license_no = ? WHERE id = ?");
    $update_query->bind_param("sssssi", $name, $disease_type, $email, $phone, $license_no, $doctor_id);
    $update_query->execute();

    header("Location: profile/view_profile.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Edit Profile</title>
    <link rel="stylesheet" href="../patient/patient_style/dashboard_style.css">
    <style>
        .edit-profile-section {
            background: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            margin: 20px auto;
            max-width: 600px;
        }
        .edit-profile-form {
            display: grid;
            grid-template-columns: 1fr;
            gap: 15px;
        }
        .form-field {
            margin-bottom: 10px;
        }
        .form-field label {
            font-weight: bold;
            display: block;
            margin-bottom: 5px;
            color: #333;
        }
        .form-field input {
            width: 100%;
            padding: 8px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        .save-profile-btn {
            background: #4CAF50;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            margin-top: 10px;
            text-align: center;
            display: block;
        }
        .save-profile-btn:hover {
            background: #45a049;
        }
    </style>
</head>
<body>
    <?php include '../patient/nav/back.html'; ?>
    <div class="edit-profile-section">
        <h2>Edit Profile</h2>
        <form class="edit-profile-form" method="post" action="">
            <div class="form-field">
                <label>Name:</label>
                <input type="text" name="name" value="<?php echo htmlspecialchars($doctor['name']); ?>" required>
            </div>
            <div class="form-field">
                <label>Specialization:</label>
                <input type="text" name="disease_type" value="<?php echo htmlspecialchars($doctor['disease_type']); ?>" required>
            </div>
            <div class="form-field">
                <label>Email:</label>
                <input type="email" name="email" value="<?php echo htmlspecialchars($doctor['email']); ?>" required>
            </div>
            <div class="form-field">
                <label>Phone:</label>
                <input type="text" name="phone" value="<?php echo htmlspecialchars($doctor['phone']); ?>" required>
            </div>
            <div class="form-field">
                <label>License Number:</label>
                <input type="text" name="license_no" value="<?php echo htmlspecialchars($doctor['license_no']); ?>" required>
            </div>
            <!-- <div class="form-field">
                <label>Experience:</label>
                <input type="text" name="experience" value="<?php echo htmlspecialchars($doctor['experience']); ?>" required>
            </div> -->
            <button type="submit" class="save-profile-btn">Save Profile</button>
        </form>
    </div>
</body>
</html>