<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);
require_once('../db_connect.php');

// Check if the doctor is logged in
if (!isset($_SESSION['doctor_id'])) {
    header("Location: ../doctor_login.php");
    exit();
}

$doctor_id = $_SESSION['doctor_id'];

// Fetch operations assigned to the logged-in doctor
$sql = "SELECT o.operation_id, p.fname AS patient_fname, p.lname AS patient_lname, o.operation_date, o.operation_type, o.notes
        FROM operations o
        JOIN patient p ON o.patient_id = p.patient_id
        WHERE o.doctor_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $doctor_id);
$stmt->execute();
$result = $stmt->get_result();

// Update operation date
if (isset($_POST['update_date'])) {
    $operation_id = (int)$_POST['operation_id'];
    $operation_date = $_POST['operation_date'];

    $update_sql = "UPDATE operations SET operation_date = ? WHERE operation_id = ?";
    $update_stmt = $conn->prepare($update_sql);
    if (!$update_stmt) {
        die("Prepare failed: " . mysqli_error($conn));
    }
    $update_stmt->bind_param("si", $operation_date, $operation_id);

    if ($update_stmt->execute()) {
        echo "Operation date updated successfully!<br>";
    } else {
        echo "Error updating operation date: " . $update_stmt->error . "<br>";
    }
}

// Delete operation
if (isset($_POST['delete_operation'])) {
    $operation_id = (int)$_POST['operation_id'];

    $delete_sql = "DELETE FROM operations WHERE operation_id = ?";
    $delete_stmt = $conn->prepare($delete_sql);
    if (!$delete_stmt) {
        die("Prepare failed: " . mysqli_error($conn));
    }
    $delete_stmt->bind_param("i", $operation_id);

    if ($delete_stmt->execute()) {
        echo "Operation deleted successfully!<br>";
    } else {
        echo "Error deleting operation: " . $delete_stmt->error . "<br>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Operations</title>
    <link rel="stylesheet" href="../dashboard_style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>
        .operation-table {
            width: 90%;
            margin: 2rem auto;
            border-collapse: collapse;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        th {
            background-color: #4CAF50;
            color: white;
        }
        tr:hover {
            background-color: #f1f1f1;
        }
        .edit-btn, .delete-btn {
            padding: 6px 12px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        .edit-btn {
            background-color: #4CAF50;
            color: white;
        }
        .delete-btn {
            background-color: #f44336;
            color: white;
        }
    </style>
</head>
<body>
    <?php include './nav/back.html'; ?>
    <div class="operation-table">
        <h1 style="text-align: center;">Edit Operations</h1>
        <table>
            <thead>
                <tr>
                    <th>Operation ID</th>
                    <th>Patient Name</th>
                    <th>Operation Date</th>
                    <th>Operation Type</th>
                    <th>Notes</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php
                if ($result && $result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        $patient_name = $row['patient_fname'] . ' ' . $row['patient_lname'];
                        echo "<tr>";
                        echo "<td>{$row['operation_id']}</td>";
                        echo "<td>{$patient_name}</td>";
                        echo "<td>
                                <form method='POST' style='display:inline;'>
                                    <input type='hidden' name='operation_id' value='{$row['operation_id']}'>
                                    <input type='date' name='operation_date' value='{$row['operation_date']}' required>
                                    <button type='submit' name='update_date' class='edit-btn'>Update</button>
                                </form>
                              </td>";
                        echo "<td>{$row['operation_type']}</td>";
                        echo "<td>{$row['notes']}</td>";
                        echo "<td>
                                <form method='POST' style='display:inline;'>
                                    <input type='hidden' name='operation_id' value='{$row['operation_id']}'>
                                    <button type='submit' name='delete_operation' class='delete-btn'>Delete</button>
                                </form>
                              </td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='6'>No operations found.</td></tr>";
                }
                ?>
            </tbody>
        </table>
    </div>
    <?php include '../footer.php'; ?>
</body>
</html>