<?php
session_start();
if (!isset($_SESSION['doctor_id'])) {
    header("Location: ./doctor_login.php");
    exit();
}
include '../../db_connect.php';

// Get doctor's information
$doctor_id = $_SESSION['doctor_id'];
$doctor_query = $conn->query("SELECT * FROM doctors WHERE id = '$doctor_id'");
$doctor = $doctor_query->fetch_assoc();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Doctor Profile</title>
    <link rel="stylesheet" href="../../patient/patient_style/dashboard_style.css">

    <style>
        .profile-section {
            background: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            margin: 20px auto;
            max-width: 600px;
        }
        .profile-info {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 15px;
        }
        .profile-field {
            margin-bottom: 10px;
        }
        .profile-field label {
            font-weight: bold;
            display: block;
            margin-bottom: 5px;
            color: #333;
        }
        .profile-field span {
            color: #666;
        }
        .edit-profile-btn {
            background: #2196F3;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            margin-top: 10px;
            text-align: center;
            display: block;
        }
        .edit-profile-btn:hover {
            background: #1976D2;
        }
    </style>
</head>
<body>
    <?php include '../../patient/nav/back.html'; ?>
    <div class="profile-section">
        <h2>Doctor Profile</h2>
        <div class="profile-info">
            <div class="profile-field">
                <label>Name:</label>
                <span><?php echo htmlspecialchars($doctor['name']); ?></span>
            </div>
            <div class="profile-field">
                <label>Specialization:</label>
                <span><?php echo htmlspecialchars($doctor['disease_type']); ?></span>
            </div>
            <div class="profile-field">
                <label>Email:</label>
                <span><?php echo htmlspecialchars($doctor['email']); ?></span>
            </div>
            <div class="profile-field">
                <label>Phone:</label>
                <span><?php echo htmlspecialchars($doctor['phone']); ?></span>
            </div>
            <div class="profile-field">
                <label>License Number:</label>
                <span><?php echo htmlspecialchars($doctor['license_no']); ?></span>
            </div>
            <!-- <div class="profile-field">
                <label>Experience:</label>
                <span><?php echo htmlspecialchars($doctor['experience']); ?> years</span>
            </div> -->
        </div>
        <a href="../edit_profile.php" class="edit-profile-btn">Edit Profile</a>
    </div>
</body>
</html>