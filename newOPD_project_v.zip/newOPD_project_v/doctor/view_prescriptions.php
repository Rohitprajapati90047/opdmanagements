<?php
session_start();
include '../db_connect.php';

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if (!isset($_SESSION['doctor_id']) && !isset($_SESSION['patient_id'])) {
    exit('Invalid request');
}

$username = $_GET['username'];

// Fetch patient_id using username
$patient_query = "SELECT patient_id FROM patient WHERE username = ?";
$patient_stmt = $conn->prepare($patient_query);
$patient_stmt->bind_param("s", $username);
$patient_stmt->execute();
$patient_result = $patient_stmt->get_result();

if ($patient_result->num_rows == 0) {
    exit('Invalid patient username');
}

$patient = $patient_result->fetch_assoc();
$patient_id = $patient['patient_id'];

// Fetch prescriptions and medicines
$sql = "SELECT p.id AS prescription_id, p.created_at, p.disease, p.consultation_notes,
               pm.medicine_name, pm.dosage, pm.duration, 
               pat.fname, pat.lname, d.name AS doctor_name
        FROM prescriptions p
        JOIN prescription_medicines pm ON p.id = pm.prescription_id
        JOIN patient pat ON p.patient_id = pat.patient_id
        JOIN doctors d ON p.doctor_id = d.id
        WHERE p.patient_id = ?
        ORDER BY p.created_at DESC";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $patient_id);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Prescription History</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
        }
        .prescription {
            border: 1px solid #ccc;
            padding: 15px;
            margin-bottom: 10px;
            border-radius: 8px;
        }
        h2, h3, h4 {
            color: #333;
        }
        ul {
            list-style-type: square;
        }
        p, li {
            margin: 5px 0;
        }
        a {
            text-decoration: none;
            color: blue;
        }
        a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <h2>Prescription History</h2>
    <?php
    if ($result->num_rows > 0) {
        $current_prescription = null;
        while ($row = $result->fetch_assoc()) {
            if ($current_prescription != $row['prescription_id']) {
                if ($current_prescription != null) {
                    echo "</ul></div>";
                }
                ?>
                <div class="prescription">
                    <h3>Date: <?php echo $row['created_at']; ?></h3>
                    <p>Patient: <?php echo htmlspecialchars($row['fname'] . ' ' . $row['lname']); ?></p>
                    <p>Doctor: <?php echo htmlspecialchars($row['doctor_name']); ?></p>
                    <p>Disease: <?php echo htmlspecialchars($row['disease']); ?></p>
                    <p>Consultation Notes: <?php echo htmlspecialchars($row['consultation_notes']); ?></p>
                    <h4>Medicines:</h4>
                    <ul>
                <?php
                $current_prescription = $row['prescription_id'];
            }
            ?>
            <li><?php echo htmlspecialchars($row['medicine_name']) . ' - ' . htmlspecialchars($row['dosage']) . ' - ' . htmlspecialchars($row['duration']); ?></li>
            <?php
        }
        if ($current_prescription != null) {
            echo "</ul></div>";
        }
    } else {
        echo "<p>No prescriptions found for this patient.</p>";
    }
    ?>
    <p><a href="doctor_dashboard.php">Back to Dashboard</a></p>
</body>
</html>