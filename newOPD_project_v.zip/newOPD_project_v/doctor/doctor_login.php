<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

include '../db_connect.php';
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = $_POST['password'];

    $sql = "SELECT * FROM doctors WHERE email=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();

    if ($row && password_verify($password, $row['password'])) {
        $_SESSION['doctor_id'] = $row['id'];
        $_SESSION['doctor_name'] = $row['name'];
        exit(header("Location: doctor_dashboard.php"));
    } else {
        $error_message = "Invalid credentials!";
    }
    $stmt->close();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Doctor Login</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="drLogin.css">
</head>
<body>
    <?php if(isset($error_message)): ?>
        <div class="error"><?php echo $error_message; ?></div>
    <?php endif; ?>
    
    <form method="post">
        Doctor Login
        <input type="email" name="email" placeholder="Email" required><br>
        <input type="password" name="password" placeholder="Password" required><br>
        <p>Don't have an account? <a href="register_doctor.php" style="text-decoration:none">Register</a></p>   
        <a href="../doctor/forget/forgot_password.php" style="text-decoration:none" >Forgot Password</a>
        <br>
        <br>
        <button type="submit">Login</button>
    </form>
</body>
</html>
