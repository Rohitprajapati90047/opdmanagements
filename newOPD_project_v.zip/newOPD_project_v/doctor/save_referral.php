<?php
include '../db_connect.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $referring_doctor_id = $_POST['referring_doctor_id'];
    $referred_doctor_id = $_POST['referred_doctor_id'];
    $reason = $_POST['reason'];

    $stmt = $conn->prepare("INSERT INTO referrals (patient_username, referring_doctor_id, referred_doctor_id, reason) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("siis", $username, $referring_doctor_id, $referred_doctor_id, $reason);

    if ($stmt->execute()) {
        echo "Referral saved successfully!";
        header("Location: doctor_dashboard.php");
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();
}
?>
