<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);
require_once('../../db_connect.php');
require '../../PHPMailer/src/PHPMailer.php';
require '../../PHPMailer/src/SMTP.php';
require '../../PHPMailer/src/Exception.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Handle AJAX request to check email existence
if (isset($_POST['check_email'])) {
    $email = mysqli_real_escape_string($conn, $_POST['email']);

    // Check if the email exists in the database
    $sql = "SELECT * FROM doctors WHERE email = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        echo "exists"; // Email exists
    } else {
        echo "not_exists"; // Email does not exist
    }
    exit();
}

// Handle OTP generation and sending
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['send_otp'])) {
    $email = mysqli_real_escape_string($conn, $_POST['email']);

    // Check if the email exists in the database
    $sql = "SELECT * FROM doctors WHERE email = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // Generate OTP
        $otp = rand(100000, 999999);
        $_SESSION['otp'] = $otp;
        $_SESSION['email'] = $email;

        // Send OTP via email
        $mail = new PHPMailer(true);
        try {
            // Server settings
            $mail->isSMTP();
            $mail->Host = 'smtp.gmail.com'; // Use your SMTP server
            $mail->SMTPAuth = true;
            $mail->Username = 'rohitprajapati332024@gmail.com'; // Your email address
            $mail->Password = 'tzzpwsavrnlkmmhv'; // Your App Password
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
            $mail->Port = 587;

            // Recipients
            $mail->setFrom('rohitprajapati332024@gmail.com', 'OPD System');
            $mail->addAddress($email);

            // Content
            $mail->isHTML(true);
            $mail->Subject = 'Your OTP for Password Reset';
            $mail->Body = "Your OTP for password reset is: <b>$otp</b>";

            $mail->send();
            echo "OTP sent to your email.";
            header("Location: verify_otp.php");
            exit();
        } catch (Exception $e) {
            $error_message = "Error sending OTP: " . $mail->ErrorInfo;
        }
    } else {
        $error_message = "Email not found!";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Forgot Password</title>
    <link rel="stylesheet" href="forgot_password.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        $(document).ready(function () {
            $('#email').on('input', function () {
                var email = $(this).val();
                if (email.length > 0) {
                    $.ajax({
                        url: 'forgot_password.php',
                        type: 'POST',
                        data: { check_email: true, email: email },
                        success: function (response) {
                            if (response === 'exists') {
                                $('#email_status').text('Email found!').css('color', 'green');
                            } else {
                                $('#email_status').text('Email not found!').css('color', 'red');
                            }
                        }
                    });
                } else {
                    $('#email_status').text('');
                }
            });
        });
        function handleCancel() {
        if (confirm("Are you sure you want to cancel the OTP Verification?")) {
        window.location.href = "../doctor_login.php";
    }}
    </script>
</head>
<body>
    
    <?php if (isset($error_message)): ?>
        <div class="error"><?php echo $error_message; ?></div>
    <?php endif; ?>
    <form method="POST">
    <h1>Forgot Password</h1>
        <label for="email">Enter your email:</label><br>
        <input type="email" name="email" id="email" required><br>
        <span id="email_status"></span><br><br>
        <button type="submit" name="send_otp">Send OTP</button>
        <button type="button" onclick="handleCancel()" style="background-color: red;margin-top: 10px;">Cancel</button>
    </form>
</body>
</html>