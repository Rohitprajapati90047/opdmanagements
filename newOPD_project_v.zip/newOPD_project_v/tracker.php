<?php
// DB connection
$conn = new mysqli("localhost", "root", "", "opd_management");
if ($conn->connect_error) return;

// Get user IP and page
$ip = $_SERVER['REMOTE_ADDR'];
$page = $_SERVER['REQUEST_URI'];

// Optional: Prevent duplicates (same user refresh)
$conn->query("INSERT INTO website_visits (ip_address, page_visited) VALUES ('$ip', '$page')");
?>
