<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>OPD management system</title>
    <link rel="stylesheet" href="newstyle.css">
    

    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://maps.googleapis.com/maps/api/js?key=YOUR_API_KEY&callback=initMap" async defer></script>
</head>

<body>
    <nav class="navbar">
        <ul class="nav-list">
            <div class="logo"><img src="./asset/hospital_logo.png" alt="logo"></div>
            <li><a href="./index.php">Home</a></li>
            <li><a href="patient/nav/service.php">Service</a></li>
            <li><a href="patient/nav/about.php">About</a></li>
            <li><a href="patient/nav/contact.php">Contact Us</a></li>
            <li><a href="patient/nav/gallery.php">Gallery</a></li>
        </ul>
        <div class="enqery">
            <img src="./asset/call.jpg" alt="call" class="call-icon">
            <a href="tel:18005884552" aria-label="Call us now">1800 5884 552</a>

        </div>
        <div class="login-btn">
            <!-- <img src="./asset/user.png" alt="no found"> -->
            <a href="multiple_user.php"><input type="button" value="Login" /></a>
        </div>
        
    </nav>
    <div class="Dborder"></div>

    <div class="slider">
        <div class="slides">
        <div class="slide">
                <img src="./asset/Designer (1).jpeg" alt="Image 3">
                <div class="slide-text">Efficient Patient Care System
                    <p style=" text-shadow: 2px 2px 5px rgba(0, 0, 0, 0.7);color:white;">"Efficient care, because every minute counts in your health journey."</p>
                    <button id="bookAppointmentBtn"
                        onclick="window.location.href='/newOPD_Project_v/patient/login.html';">
                        Book Appointment
                    </button>
                </div>
            </div>

            <div class="slide">
                <img src="./asset/slide-1.jpg" alt="Image 1">
                <div class="slide-text">Welcome to OPD Management
                <p style=" text-shadow: 2px 2px 5px rgba(0, 0, 0, 0.7);color:white;">"Where care meets convenience, every patient is our priority."</p>             
                </div>
            </div>
            <div class="slide">
                <img src="./asset/slide-2.jpg" alt="Image 2">
                <div class="slide-text">Book Your Appointment Online
                <p style=" text-shadow: 2px 2px 5px rgba(0, 0, 0, 0.7);color:white;">"Skip the wait, book your appointment online today!"</p>
                </div>
            </div>
            
        </div>
    </div>

    <div class="section1">
        <div class="carousel-container">
            <div class="carousel">
                <div class="card">
                    <img src="./asset/img/doctors/dr4.jpg" alt="Doctor 1">
                    <h3>Dr. Parax Alex</h3>
                    <p>Dermatologist Specialist</p>
                </div>
                <div class="card">
                    <img src="./asset/img/doctors/dr2.jpg" alt="Doctor 2">
                    <h3>Dr. dox Alwin</h3>
                    <p>Otolaryngologist Specialist</p>
                </div>
                <div class="card">
                    <img src="./asset/img/doctors/doctor_3.jpg" alt="Doctor 3">
                    <h3>Dr. Param JOGH</h3>
                    <p>General Physician</p>
                </div>
                <div class="card">
                    <img src="./asset/img/doctors/dr1.jpg" alt="Doctor 4">
                    <h3>Dr. Paksha Hunger</h3>
                    <p>Cardiologist Specialist</p>
                </div>
            </div>
        </div>
    </div>

    <div class="section2">
        <h2>Events & Updates</h2>
        <div class="updates-container">
            <div class="update">
                <img src="./asset/section/world-parkinsons-day.jpg" alt="Event 1" class="update-image">
                <h3>Breakthrough in Cancer Treatment</h3>
                <p>Researchers have developed a new therapy that significantly improves cancer survival rates.</p>
                <a href="events/cancer-treatment-details.html">Read More</a>
            </div>
            <div class="update">
                <img src="./asset/section/ibm-seminar.jpg" alt="Event 2" class="update-image">
                <h3>Telemedicine Gains Popularity</h3>
                <p>More patients are opting for remote consultations amid the ongoing healthcare challenges.</p>
                <a href="./events/telemedicine-details.html">Read More</a>
            </div>
            <div class="update">
                <img src="./asset/section/bmt.jpg" alt="Event 3" class="update-image">
                <h3>Advances in Medical Imaging Technology</h3>
                <p>New imaging techniques offer higher precision and faster diagnosis of complex conditions.</p>
                <a href="./events/AdvancesTechnology.html">Read More</a>
            </div>
        </div>
    </div>

    <!-- dashboard with pi chart  -->
    <div class="dashboard" id="dashboard">
    <div class="card">
        <h2>Total Visits</h2>
        <p id="visits">Loading...</p>
    </div>
    <div class="card">
        <h2>Total Registrations</h2>
        <p id="registrations">Loading...</p>
    </div>
</div>

<?php include 'tracker.php'; ?>

    
    <h3 style="color:black">📍 Rajawadi Hospital – View on Google Maps</h3>
    <div id="map"></div>
<div class="map-container">
    <iframe 
        width="100%" 
        height="400" 
        frameborder="0" 
        style="border:0;" 
        allowfullscreen 
        loading="lazy" 
        referrerpolicy="no-referrer-when-downgrade" 
        src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3768.4729501412343!2d72.89767237584458!3d19.07613574533442!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3be7c89c73bd3f27%3A0xc30d046d4fe12c46!2sRajawadi%20Hospital!5e0!3m2!1sen!2sin!4v1690222334238!5m2!1sen!2sin">
    </iframe>
</div>

    
    <script src="newscript.js"></script>
</body>

</html>
<?php include 'footer.php'; ?>
