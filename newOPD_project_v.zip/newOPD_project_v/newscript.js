// ===== NAVBAR SCROLL EFFECT =====
window.addEventListener('scroll', function() {
    const navbar = document.querySelector('.navbar');
    if (window.scrollY > 50) {
        navbar.classList.add('scrolled');
    } else {
        navbar.classList.remove('scrolled');
    }
});

// ===== MOBILE MENU TOGGLE =====
// First, let's add the menu toggle button to the HTML via JavaScript
document.addEventListener('DOMContentLoaded', function() {
    // Create menu toggle button
    const menuToggle = document.createElement('div');
    menuToggle.className = 'menu-toggle';
    for (let i = 0; i < 3; i++) {
        const span = document.createElement('span');
        menuToggle.appendChild(span);
    }
    
    // Insert before the login button
    const loginBtn = document.querySelector('.login-btn');
    const navbar = document.querySelector('.navbar');
    navbar.insertBefore(menuToggle, loginBtn);
    
    // Add event listener
    menuToggle.addEventListener('click', function() {
        this.classList.toggle('active');
        document.querySelector('.nav-list').classList.toggle('active');
    });
});

// ===== SLIDER FUNCTIONALITY =====
document.addEventListener('DOMContentLoaded', function() {
    // Create slider navigation dots
    const slider = document.querySelector('.slider');
    const slides = document.querySelectorAll('.slide');
    
    const sliderNav = document.createElement('div');
    sliderNav.className = 'slider-nav';
    
    slides.forEach((_, index) => {
        const dot = document.createElement('div');
        dot.className = 'slider-dot';
        if (index === 0) dot.classList.add('active');
        
        dot.addEventListener('click', () => {
            document.querySelector('.slides').style.transform = `translateX(-${index * 33.33}%)`;
            document.querySelectorAll('.slider-dot').forEach(d => d.classList.remove('active'));
            dot.classList.add('active');
        });
        
        sliderNav.appendChild(dot);
    });
    
    slider.appendChild(sliderNav);
    
    // Update active dot during automatic slideshow
    let currentSlide = 0;
    setInterval(() => {
        currentSlide = (currentSlide + 1) % 3;
        document.querySelectorAll('.slider-dot').forEach((dot, index) => {
            dot.classList.toggle('active', index === currentSlide);
        });
    }, 5000);
});

// ===== DOCTORS CAROUSEL NAVIGATION =====
document.addEventListener('DOMContentLoaded', function() {
    const carouselContainer = document.querySelector('.carousel-container');
    const carousel = document.querySelector('.carousel');
    const cards = document.querySelectorAll('.carousel .card');
    
    // Create navigation buttons
    const carouselNav = document.createElement('div');
    carouselNav.className = 'carousel-nav';
    
    const prevBtn = document.createElement('button');
    prevBtn.className = 'carousel-btn prev';
    prevBtn.innerHTML = '&#10094;';
    
    const nextBtn = document.createElement('button');
    nextBtn.className = 'carousel-btn next';
    nextBtn.innerHTML = '&#10095;';
    
    carouselNav.appendChild(prevBtn);
    carouselNav.appendChild(nextBtn);
    carouselContainer.appendChild(carouselNav);
    
    // Calculate the number of visible cards based on screen width
    function getVisibleCards() {
        if (window.innerWidth < 576) return 1;
        if (window.innerWidth < 768) return 2;
        if (window.innerWidth < 1024) return 3;
        return 4;
    }
    
    let currentIndex = 0;
    const totalCards = cards.length;
    
    function updateCarousel() {
        const visibleCards = getVisibleCards();
        const maxIndex = totalCards - visibleCards;
        
        if (currentIndex > maxIndex) currentIndex = maxIndex;
        
        const cardWidth = cards[0].offsetWidth;
        const gap = 32; // 2rem gap
        const translateX = currentIndex * -(cardWidth + gap);
        
        carousel.style.transform = `translateX(${translateX}px)`;
        
        // Update button states
        prevBtn.disabled = currentIndex === 0;
        nextBtn.disabled = currentIndex >= maxIndex;
        
        prevBtn.style.opacity = prevBtn.disabled ? '0.5' : '1';
        nextBtn.style.opacity = nextBtn.disabled ? '0.5' : '1';
    }
    
    // Event listeners for buttons
    prevBtn.addEventListener('click', () => {
        if (currentIndex > 0) {
            currentIndex--;
            updateCarousel();
        }
    });
    
    nextBtn.addEventListener('click', () => {
        const visibleCards = getVisibleCards();
        const maxIndex = totalCards - visibleCards;
        
        if (currentIndex < maxIndex) {
            currentIndex++;
            updateCarousel();
        }
    });
    
    // Update on window resize
    window.addEventListener('resize', updateCarousel);
    
    // Initial update
    updateCarousel();
});

// ===== DASHBOARD COUNTER ANIMATION =====
document.addEventListener('DOMContentLoaded', function () {
    const dashboard = document.getElementById('dashboard');

    function animateCounter(id, endValue) {
        let current = 0;
        const increment = Math.ceil(endValue / 100);
        const el = document.getElementById(id);

        const interval = setInterval(() => {
            current += increment;
            if (current >= endValue) {
                clearInterval(interval);
                current = endValue;
            }
            el.textContent = current;
        }, 20);
    }

    fetch('dashboard-data.php')
        .then(res => res.json())
        .then(data => {
            if (data.error) {
                dashboard.innerHTML = `<p>Error: ${data.error}</p>`;
                return;
            }

            animateCounter('visits', parseInt(data.visits));
            animateCounter('registrations', parseInt(data.registrations));
        })
        .catch(err => {
            dashboard.innerHTML = `<p>Failed to load dashboard data.</p>`;
            console.error(err);
        });
});


// ===== SCROLL REVEAL ANIMATION =====
document.addEventListener('DOMContentLoaded', function() {
    const revealElements = document.querySelectorAll('.section1, .section2, .dashboard, .charts');
    
    function checkReveal() {
        revealElements.forEach(element => {
            const elementTop = element.getBoundingClientRect().top;
            const windowHeight = window.innerHeight;
            
            if (elementTop < windowHeight - 100) {
                element.classList.add('fadeIn');
            }
        });
    }
    
    // Add initial classes
    revealElements.forEach(element => {
        element.style.opacity = '0';
    });
    
    // Check on scroll
    window.addEventListener('scroll', checkReveal);
    
    // Initial check
    checkReveal();
});

//=================map pointer ==============//
// function initMap() {
//     // The location of Rajawadi Hospital
//     const rajawadi = { lat: 19.07613574533442, lng: 72.89767237584458 };
    
//     // Create a map centered on Rajawadi Hospital
//     const map = new google.maps.Map(document.getElementById("map"), {
//         zoom: 15, // Set zoom level
//         center: rajawadi,
//     });

//     // Add a custom marker on the map
//     const marker = new google.maps.Marker({
//         position: rajawadi,
//         map: map,
//         title: "Rajawadi Hospital", // Tooltip text when hovered
//     });

//     // Optional: Add an info window when the marker is clicked
//     const infoWindow = new google.maps.InfoWindow({
//         content: "<h4>Rajawadi Hospital</h4><p>Located in Mumbai, Maharashtra</p>",
//     });

//     marker.addListener("click", function () {
//         infoWindow.open(map, marker);
//     });
// }