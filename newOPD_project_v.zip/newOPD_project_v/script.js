let currentIndex = 0;
const slides = document.querySelectorAll('.slide');
const totalSlides = slides.length;

function nextSlide() {
    // Remove 'active' class from all slides
    slides.forEach(slide => slide.classList.remove("active"));

    // Update index and show the next slide
    currentIndex = (currentIndex + 1) % totalSlides;
    slides[currentIndex].classList.add("active");

    // Move the slider
    document.querySelector('.slides').style.transform = `translateX(-${currentIndex * 100}%)`;
}

// Auto-change slides every 3 seconds
setInterval(nextSlide, 3000);

// Initialize first slide as active+
slides[currentIndex].classList.add("active");


// dashboard code below
let lastVisits = parseInt(localStorage.getItem("lastVisits")) || 100;
let lastRegistrations = parseInt(localStorage.getItem("lastRegistrations")) || 50;
let lastHospitals = 10;

async function fetchDashboardData() {
    lastVisits = Math.min(600, lastVisits + Math.floor(Math.random() * 2 + 1));
    localStorage.setItem("lastVisits", lastVisits);
    
    lastRegistrations = Math.min(600, lastRegistrations + Math.floor(Math.random() * 2 + 1));
    localStorage.setItem("lastRegistrations", lastRegistrations);
    
    let hospChange = Math.floor(Math.random() * 10 - 5);
    lastHospitals = Math.max(5, Math.min(600, lastHospitals + hospChange));

    return {
        visits: lastVisits,
        registrations: lastRegistrations,
        hospitals: lastHospitals
    };
}

async function updateDashboard() {
    const data = await fetchDashboardData();
    document.getElementById("visits").textContent = data.visits;
    document.getElementById("registrations").textContent = data.registrations;
 
    
    updateChart("visitsChart", "Visits", data.visits, "#FF5733");
    updateChart("registrationsChart", "Registrations", data.registrations, "#33FF57");
  
}


document.addEventListener("DOMContentLoaded", updateDashboard);

// end dashboard code

window.addEventListener('scroll', function () {
    const navbar = document.querySelector('.navbar');
    if (window.scrollY > 50) {
        navbar.classList.add('scrolled');
    } else {
        navbar.classList.remove('scrolled');
    }
});


// 2

document.addEventListener('DOMContentLoaded', function () {
    const menuToggle = document.createElement('div');
    menuToggle.className = 'menu-toggle';
    for (let i = 0; i < 3; i++) {
        const span = document.createElement('span');
        menuToggle.appendChild(span);
    }

    const loginBtn = document.querySelector('.login-btn');
    const navbar = document.querySelector('.navbar');
    if (loginBtn && navbar) {
        navbar.insertBefore(menuToggle, loginBtn);
    } else if (navbar) {
        navbar.appendChild(menuToggle);
    }

    menuToggle.addEventListener('click', function () {
        this.classList.toggle('active');
        document.querySelector('.nav-list').classList.toggle('active');
    });
});

// 3

document.addEventListener('DOMContentLoaded', function () {
    const slider = document.querySelector('.slider');
    const slides = document.querySelectorAll('.slide');
    const sliderNav = document.createElement('div');
    sliderNav.className = 'slider-nav';

    slides.forEach((_, index) => {
        const dot = document.createElement('div');
        dot.className = 'slider-dot';
        if (index === 0) dot.classList.add('active');

        dot.addEventListener('click', () => {
            document.querySelector('.slides').style.transform = `translateX(-${index * 33.33}%)`;
            document.querySelectorAll('.slider-dot').forEach(d => d.classList.remove('active'));
            dot.classList.add('active');
        });

        sliderNav.appendChild(dot);
    });

    slider.appendChild(sliderNav);

    let currentSlide = 0;
    setInterval(() => {
        currentSlide = (currentSlide + 1) % 3;
        document.querySelector('.slides').style.transform = `translateX(-${currentSlide * 33.33}%)`;
        document.querySelectorAll('.slider-dot').forEach((dot, index) => {
            dot.classList.toggle('active', index === currentSlide);
        });
    }, 5000);
});


// 4
document.addEventListener('DOMContentLoaded', function () {
    const carouselContainer = document.querySelector('.carousel-container');
    const carousel = document.querySelector('.carousel');
    const cards = document.querySelectorAll('.carousel .card');

    const carouselNav = document.createElement('div');
    carouselNav.className = 'carousel-nav';

    const prevBtn = document.createElement('button');
    prevBtn.className = 'carousel-btn prev';
    prevBtn.innerHTML = '&#10094;';

    const nextBtn = document.createElement('button');
    nextBtn.className = 'carousel-btn next';
    nextBtn.innerHTML = '&#10095;';

    carouselNav.appendChild(prevBtn);
    carouselNav.appendChild(nextBtn);
    carouselContainer.appendChild(carouselNav);

    function getVisibleCards() {
        if (window.innerWidth < 576) return 1;
        if (window.innerWidth < 768) return 2;
        if (window.innerWidth < 1024) return 3;
        return 4;
    }

    let currentIndex = 0;
    const totalCards = cards.length;

    function updateCarousel() {
        const visibleCards = getVisibleCards();
        const maxIndex = totalCards - visibleCards;
        if (currentIndex > maxIndex) currentIndex = maxIndex;

        const cardWidth = cards[0].offsetWidth;
        const gap = 32; // 2rem gap
        const translateX = currentIndex * -(cardWidth + gap);

        carousel.style.transform = `translateX(${translateX}px)`;

        prevBtn.disabled = currentIndex === 0;
        nextBtn.disabled = currentIndex >= maxIndex;

        prevBtn.style.opacity = prevBtn.disabled ? '0.5' : '1';
        nextBtn.style.opacity = nextBtn.disabled ? '0.5' : '1';
    }

    prevBtn.addEventListener('click', () => {
        if (currentIndex > 0) {
            currentIndex--;
            updateCarousel();
        }
    });

    nextBtn.addEventListener('click', () => {
        const visibleCards = getVisibleCards();
        const maxIndex = totalCards - visibleCards;
        if (currentIndex < maxIndex) {
            currentIndex++;
            updateCarousel();
        }
    });

    window.addEventListener('resize', updateCarousel);
    updateCarousel();
});


// 5

document.addEventListener('DOMContentLoaded', function () {
    const revealElements = document.querySelectorAll('.section1, .section2, .dashboard, .charts');

    function checkReveal() {
        revealElements.forEach(element => {
            const elementTop = element.getBoundingClientRect().top;
            const windowHeight = window.innerHeight;
            if (elementTop < windowHeight - 100) {
                element.classList.add('fadeIn');
            }
        });
    }

    revealElements.forEach(element => {
        element.style.opacity = '0';
    });

    window.addEventListener('scroll', checkReveal);
    checkReveal();
});
