<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us - OPD Management System</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Arial', sans-serif;
        }

        :root {
            --primary-color: #1e88e5;
            --secondary-color: #0d47a1;
            --accent-color: #64b5f6;
            --text-color: #333;
            --light-color: #f5f5f5;
            --dark-color: #212121;
        }

        body {
            background-color: #f8f9fa;
            color: var(--text-color);
            line-height: 1.6;
        }

        header {
            background-color: var(--primary-color);
            color: white;
            padding: 1rem 0;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            position: sticky;
            top: 0;
            z-index: 100;
        }

        .container {
            width: 90%;
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 15px;
        }

        .header-content {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .logo {
            font-size: 1.8rem;
            font-weight: bold;
            text-decoration: none;
            color: white;
        }

        nav ul {
            display: flex;
            list-style: none;
        }

        nav ul li {
            margin-left: 1.5rem;
        }

        nav ul li a {
            color: white;
            text-decoration: none;
            font-weight: 500;
            transition: color 0.3s;
        }

        nav ul li a:hover {
            color: var(--accent-color);
        }

        .hero {
            background-image: linear-gradient(rgba(0, 0, 0, 0.6), rgba(0, 0, 0, 0.6)), url('https://images.unsplash.com/photo-1504439468489-c8920d796a29?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80');
            background-size: cover;
            background-position: center;
            color: white;
            text-align: center;
            padding: 5rem 0;
        }

        .hero h1 {
            font-size: 2.5rem;
            margin-bottom: 1rem;
        }

        .hero p {
            font-size: 1.2rem;
            max-width: 800px;
            margin: 0 auto;
        }

        .about-section {
            padding: 4rem 0;
        }

        .section-title {
            text-align: center;
            margin-bottom: 3rem;
        }

        .section-title h2 {
            font-size: 2.2rem;
            color: var(--primary-color);
            position: relative;
            display: inline-block;
            padding-bottom: 10px;
        }

        .section-title h2::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 50%;
            transform: translateX(-50%);
            width: 80px;
            height: 3px;
            background-color: var(--primary-color);
        }

        .about-content {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 3rem;
            align-items: center;
        }

        .about-image {
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
        }

        .about-image img {
            width: 100%;
            height: auto;
            display: block;
        }

        .about-text h3 {
            color: var(--primary-color);
            font-size: 1.8rem;
            margin-bottom: 1.5rem;
        }

        .about-text p {
            margin-bottom: 1.5rem;
        }

        .mission-vision {
            background-color: var(--light-color);
            padding: 4rem 0;
        }

        .mission-vision-content {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 2rem;
        }

        .mission-card, .vision-card {
            background-color: white;
            padding: 2rem;
            border-radius: 8px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.05);
            text-align: center;
        }

        .mission-card h3, .vision-card h3 {
            color: var(--primary-color);
            font-size: 1.5rem;
            margin-bottom: 1rem;
            position: relative;
            padding-bottom: 10px;
            display: inline-block;
        }

        .mission-card h3::after, .vision-card h3::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 50%;
            transform: translateX(-50%);
            width: 50px;
            height: 2px;
            background-color: var(--primary-color);
        }

        .team-section {
            padding: 4rem 0;
        }

        .team-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 2rem;
        }

        .team-member {
            background-color: white;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s, box-shadow 0.3s;
        }

        .team-member:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.1);
        }

        .member-image {
            height: 250px;
            overflow: hidden;
        }

        .member-image img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .member-info {
            padding: 1.5rem;
            text-align: center;
        }

        .member-info h3 {
            color: var(--primary-color);
            margin-bottom: 0.5rem;
        }

        .member-info p {
            color: #666;
            margin-bottom: 1rem;
        }

        .stats-section {
            background-color: var(--primary-color);
            color: white;
            padding: 4rem 0;
            text-align: center;
        }

        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 2rem;
            margin-top: 3rem;
        }

        .stat-item h3 {
            font-size: 2.5rem;
            margin-bottom: 0.5rem;
        }

        .cta-section {
            background-color: var(--light-color);
            padding: 4rem 0;
            text-align: center;
        }

        .cta-section h2 {
            font-size: 2rem;
            color: var(--primary-color);
            margin-bottom: 1.5rem;
        }

        .btn {
            display: inline-block;
            padding: 0.8rem 1.5rem;
            background-color: var(--primary-color);
            color: white;
            text-decoration: none;
            border-radius: 4px;
            font-weight: bold;
            transition: background-color 0.3s;
        }

        .btn:hover {
            background-color: var(--secondary-color);
        }

        footer {
            background-color: var(--dark-color);
            color: white;
            padding: 3rem 0;
        }

        .footer-content {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 2rem;
        }

        .footer-column h3 {
            font-size: 1.2rem;
            margin-bottom: 1.5rem;
            position: relative;
            padding-bottom: 10px;
        }

        .footer-column h3::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            width: 50px;
            height: 2px;
            background-color: var(--primary-color);
        }

        .footer-column ul {
            list-style: none;
        }

        .footer-column ul li {
            margin-bottom: 0.8rem;
        }

        .footer-column ul li a {
            color: #ccc;
            text-decoration: none;
            transition: color 0.3s;
        }

        .footer-column ul li a:hover {
            color: var(--primary-color);
        }

        .contact-info p {
            margin-bottom: 0.8rem;
            display: flex;
            align-items: center;
        }

        .contact-info i {
            margin-right: 10px;
            color: var(--primary-color);
        }

        .copyright {
            text-align: center;
            padding-top: 2rem;
            margin-top: 2rem;
            border-top: 1px solid #444;
        }

        /* Timeline */
        .timeline-section {
            padding: 4rem 0;
        }

        .timeline {
            position: relative;
            max-width: 800px;
            margin: 0 auto;
        }

        .timeline::after {
            content: '';
            position: absolute;
            width: 4px;
            background-color: var(--primary-color);
            top: 0;
            bottom: 0;
            left: 50%;
            margin-left: -2px;
        }

        .timeline-item {
            padding: 10px 40px;
            position: relative;
            width: 50%;
            box-sizing: border-box;
        }

        .timeline-item::after {
            content: '';
            position: absolute;
            width: 20px;
            height: 20px;
            background-color: white;
            border: 4px solid var(--primary-color);
            border-radius: 50%;
            top: 15px;
            z-index: 1;
        }

        .left {
            left: 0;
        }

        .right {
            left: 50%;
        }

        .left::after {
            right: -10px;
        }

        .right::after {
            left: -10px;
        }

        .timeline-content {
            padding: 20px;
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .timeline-content h3 {
            color: var(--primary-color);
            margin-bottom: 10px;
        }

        /* Responsive Design */
        @media (max-width: 992px) {
            .about-content {
                grid-template-columns: 1fr;
            }

            .mission-vision-content {
                grid-template-columns: 1fr;
            }
        }

        @media (max-width: 768px) {
            .header-content {
                flex-direction: column;
                text-align: center;
            }

            nav ul {
                margin-top: 1rem;
                justify-content: center;
            }

            nav ul li {
                margin: 0 0.7rem;
            }

            .hero h1 {
                font-size: 2rem;
            }

            .hero p {
                font-size: 1rem;
            }

            .section-title h2 {
                font-size: 1.8rem;
            }

            .timeline::after {
                left: 31px;
            }

            .timeline-item {
                width: 100%;
                padding-left: 70px;
                padding-right: 25px;
            }

            .timeline-item::after {
                left: 21px;
            }

            .left::after, .right::after {
                left: 21px;
            }

            .right {
                left: 0;
            }
        }

        @media (max-width: 480px) {
            .team-grid {
                grid-template-columns: 1fr;
            }

            .stats-grid {
                grid-template-columns: 1fr;
            }

            .footer-content {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <!-- <header>
        <div class="container">
            <div class="header-content">
                <a href="../index.php" class="logo">MediCare OPD</a>
                <nav>
                    <ul>
                        <li><a href="../index.php">Home</a></li>
                        <li><a href="service.html">Services</a></li>
                        <li><a href="about.html">About Us</a></li>
                        <li><a href="contact.html">Contact</a></li>
                    </ul>
                </nav>
            </div>
        </div>
    </header> -->
    <?php include '../nav/navbar.php'; ?>

    <section class="hero">
        <div class="container">
            <h1>About MediCare OPD</h1>
            <p>Committed to providing exceptional healthcare with compassion and excellence</p>
        </div>
    </section>

    <section class="about-section">
        <div class="container">
            <div class="section-title">
                <h2>Our Story</h2>
            </div>
            <div class="about-content">
                <div class="about-image">
                    <img src="https://images.unsplash.com/photo-1551076805-e1869033e561?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80" alt="MediCare OPD Building">
                </div>
                <div class="about-text  alt="MediCare OPD Building">
                </div>
                <div class="about-text">
                    <h3>Excellence in Healthcare Since 2005</h3>
                    <p>MediCare OPD was established in 2005 with a vision to provide accessible, high-quality outpatient care to our community. What began as a small clinic with just three doctors has now grown into a comprehensive outpatient department serving thousands of patients annually.</p>
                    <p>Our journey has been guided by our commitment to patient-centered care, medical excellence, and continuous improvement. We have consistently invested in the latest medical technologies and attracted top medical talent to ensure our patients receive the best possible care.</p>
                    <p>Today, MediCare OPD stands as a trusted healthcare provider, known for its compassionate approach, medical expertise, and state-of-the-art facilities. We take pride in being a vital part of our community's health and wellbeing.</p>
                </div>
            </div>
        </div>
    </section>

    <section class="mission-vision">
        <div class="container">
            <div class="section-title">
                <h2>Our Mission & Vision</h2>
            </div>
            <div class="mission-vision-content">
                <div class="mission-card">
                    <h3>Our Mission</h3>
                    <p>To provide exceptional outpatient healthcare services that improve the health and wellbeing of our community through compassionate care, medical excellence, and patient-centered approaches.</p>
                </div>
                <div class="vision-card">
                    <h3>Our Vision</h3>
                    <p>To be the leading outpatient care provider, recognized for excellence in healthcare delivery, innovation in medical practices, and unwavering commitment to patient satisfaction and community health.</p>
                </div>
            </div>
        </div>
    </section>

    <section class="team-section">
        <div class="container">
            <div class="section-title">
                <h2>Our Leadership Team</h2>
            </div>
            <div class="team-grid">
                <div class="team-member">
                    <div class="member-image">
                        <img src="https://images.unsplash.com/photo-1559839734-2b71ea197ec2?ixlib=rb-1.2.1&auto=format&fit=crop&w=634&q=80" alt="Dr. Sarah Johnson">
                    </div>
                    <div class="member-info">
                        <h3>Dr. Sarah Johnson</h3>
                        <p>Medical Director</p>
                        <p>Dr. Johnson brings over 20 years of experience in healthcare management and internal medicine.</p>
                    </div>
                </div>

                <div class="team-member">
                    <div class="member-image">
                        <img src="https://images.unsplash.com/photo-1622253692010-333f2da6031d?ixlib=rb-1.2.1&auto=format&fit=crop&w=634&q=80" alt="Dr. Michael Chen">
                    </div>
                    <div class="member-info">
                        <h3>Dr. Michael Chen</h3>
                        <p>Chief of Cardiology</p>
                        <p>A renowned cardiologist with numerous publications and innovations in cardiac care.</p>
                    </div>
                </div>

                <div class="team-member">
                    <div class="member-image">
                        <img src="https://images.unsplash.com/photo-1594824476967-48c8b964273f?ixlib=rb-1.2.1&auto=format&fit=crop&w=634&q=80" alt="Dr. Emily Rodriguez">
                    </div>
                    <div class="member-info">
                        <h3>Dr. Emily Rodriguez</h3>
                        <p>Head of Pediatrics</p>
                        <p>Specializing in pediatric care for over 15 years, Dr. Rodriguez is beloved by our youngest patients.</p>
                    </div>
                </div>

                <div class="team-member">
                    <div class="member-image">
                        <img src="https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?ixlib=rb-1.2.1&auto=format&fit=crop&w=634&q=80" alt="Dr. James Wilson">
                    </div>
                    <div class="member-info">
                        <h3>Dr. James Wilson</h3>
                        <p>Chief of Operations</p>
                        <p>With a background in both medicine and business administration, Dr. Wilson ensures our operations run smoothly.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="timeline-section">
        <div class="container">
            <div class="section-title">
                <h2>Our Journey</h2>
            </div>
            <div class="timeline">
                <div class="timeline-item left">
                    <div class="timeline-content">
                        <h3>2005</h3>
                        <p>MediCare OPD was founded with a small team of three doctors and five support staff.</p>
                    </div>
                </div>
                <div class="timeline-item right">
                    <div class="timeline-content">
                        <h3>2010</h3>
                        <p>Expanded our services to include specialized departments for cardiology, pediatrics, and orthopedics.</p>
                    </div>
                </div>
                <div class="timeline-item left">
                    <div class="timeline-content">
                        <h3>2015</h3>
                        <p>Moved to our current state-of-the-art facility, tripling our capacity to serve patients.</p>
                    </div>
                </div>
                <div class="timeline-item right">
                    <div class="timeline-content">
                        <h3>2020</h3>
                        <p>Implemented advanced electronic health records system and telemedicine services.</p>
                    </div>
                </div>
                <div class="timeline-item left">
                    <div class="timeline-content">
                        <h3>2025</h3>
                        <p>Celebrating 20 years of excellence in healthcare with plans for further expansion.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="stats-section">
        <div class="container">
            <div class="section-title">
                <h2>Our Impact</h2>
            </div>
            <div class="stats-grid">
                <div class="stat-item">
                    <h3>50,000+</h3>
                    <p>Patients Served Annually</p>
                </div>
                <div class="stat-item">
                    <h3>30+</h3>
                    <p>Specialized Doctors</p>
                </div>
                <div class="stat-item">
                    <h3>15+</h3>
                    <p>Medical Specialties</p>
                </div>
                <div class="stat-item">
                    <h3>98%</h3>
                    <p>Patient Satisfaction</p>
                </div>
            </div>
        </div>
    </section>

    <section class="cta-section">
        <div class="container">
            <h2>Experience Our Care Firsthand</h2>
            <p>Schedule an appointment today and discover the MediCare OPD difference</p>
            <a href="contact.html" class="btn">Contact Us</a>
        </div>
    </section>

    <footer>
        <div class="container">
            <div class="footer-content">
                <div class="footer-column">
                    <h3>MediCare OPD</h3>
                    <p>Providing quality healthcare services with compassion and excellence since 2005.</p>
                </div>
                <div class="footer-column">
                    <h3>Quick Links</h3>
                    <ul>
                        <li><a href="../index.php">Home</a></li>
                        <li><a href="./service.html">Services</a></li>
                        <li><a href="./about.html">About Us</a></li>
                        <li><a href="./contact.html">Contact</a></li>
                    </ul>
                </div>
                <div class="footer-column">
                    <h3>Our Services</h3>
                    <ul>
                        <li><a href="#">General Consultation</a></li>
                        <li><a href="#">Laboratory Services</a></li>
                        <li><a href="#">Cardiology</a></li>
                        <li><a href="#">Pediatric Care</a></li>
                    </ul>
                </div>
                <div class="footer-column contact-info">
                    <h3>Contact Us</h3>
                    <p><i>📍</i> 123 Medical Center Drive, Healthcare City</p>
                    <p><i>📞</i> +1 (555) 123-4567</p>
                    <p><i>✉️</i> info@medicareOPD.com</p>
                </div>
            </div>
            <div class="copyright">
                <p>&copy; 2025 MediCare OPD. All Rights Reserved.</p>
            </div>
        </div>
    </footer>
</body>
</html>