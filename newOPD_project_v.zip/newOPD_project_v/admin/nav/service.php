<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Our Services - OPD Management System</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Arial', sans-serif;
        }

        :root {
            --primary-color: #1e88e5;
            --secondary-color: #0d47a1;
            --accent-color: #64b5f6;
            --text-color: #333;
            --light-color: #f5f5f5;
            --dark-color: #212121;
        }

        body {
            background-color: #f8f9fa;
            color: var(--text-color);
            line-height: 1.6;
        }

        header {
            background-color: var(--primary-color);
            color: white;
            padding: 1rem 0;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            position: sticky;
            top: 0;
            z-index: 100;
        }

        .container {
            width: 90%;
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 15px;
        }

        .header-content {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .logo {
            font-size: 1.8rem;
            font-weight: bold;
            text-decoration: none;
            color: white;
        }

        nav ul {
            display: flex;
            list-style: none;
        }

        nav ul li {
            margin-left: 1.5rem;
        }

        nav ul li a {
            color: white;
            text-decoration: none;
            font-weight: 500;
            transition: color 0.3s;
        }

        nav ul li a:hover {
            color: var(--accent-color);
        }

        .hero {
            background-image: linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)), url('https://images.unsplash.com/photo-1519494026892-80bbd2d6fd0d?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80');
            background-size: cover;
            background-position: center;
            color: white;
            text-align: center;
            padding: 5rem 0;
        }

        .hero h1 {
            font-size: 2.5rem;
            margin-bottom: 1rem;
        }

        .hero p {
            font-size: 1.2rem;
            max-width: 800px;
            margin: 0 auto;
        }

        .services-section {
            padding: 4rem 0;
        }

        .section-title {
            text-align: center;
            margin-bottom: 3rem;
        }

        .section-title h2 {
            font-size: 2.2rem;
            color: var(--primary-color);
            position: relative;
            display: inline-block;
            padding-bottom: 10px;
        }

        .section-title h2::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 50%;
            transform: translateX(-50%);
            width: 80px;
            height: 3px;
            background-color: var(--primary-color);
        }

        .services-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 2rem;
        }

        .service-card {
            background-color: white;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s, box-shadow 0.3s;
        }

        .service-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.1);
        }

        .service-icon {
            background-color: var(--primary-color);
            color: white;
            padding: 2rem;
            text-align: center;
            font-size: 2.5rem;
        }

        .service-content {
            padding: 1.5rem;
        }

        .service-content h3 {
            color: var(--primary-color);
            margin-bottom: 1rem;
        }

        .cta-section {
            background-color: var(--primary-color);
            color: white;
            padding: 4rem 0;
            text-align: center;
        }

        .cta-section h2 {
            font-size: 2rem;
            margin-bottom: 1.5rem;
        }

        .btn {
            display: inline-block;
            padding: 0.8rem 1.5rem;
            background-color: white;
            color: var(--primary-color);
            text-decoration: none;
            border-radius: 4px;
            font-weight: bold;
            transition: background-color 0.3s, color 0.3s;
        }

        .btn:hover {
            background-color: var(--secondary-color);
            color: white;
        }

        footer {
            background-color: var(--dark-color);
            color: white;
            padding: 3rem 0;
        }

        .footer-content {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 2rem;
        }

        .footer-column h3 {
            font-size: 1.2rem;
            margin-bottom: 1.5rem;
            position: relative;
            padding-bottom: 10px;
        }

        .footer-column h3::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            width: 50px;
            height: 2px;
            background-color: var(--primary-color);
        }

        .footer-column ul {
            list-style: none;
        }

        .footer-column ul li {
            margin-bottom: 0.8rem;
        }

        .footer-column ul li a {
            color: #ccc;
            text-decoration: none;
            transition: color 0.3s;
        }

        .footer-column ul li a:hover {
            color: var(--primary-color);
        }

        .contact-info p {
            margin-bottom: 0.8rem;
            display: flex;
            align-items: center;
        }

        .contact-info i {
            margin-right: 10px;
            color: var(--primary-color);
        }

        .copyright {
            text-align: center;
            padding-top: 2rem;
            margin-top: 2rem;
            border-top: 1px solid #444;
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .header-content {
                flex-direction: column;
                text-align: center;
            }

            nav ul {
                margin-top: 1rem;
                justify-content: center;
            }

            nav ul li {
                margin: 0 0.7rem;
            }

            .hero h1 {
                font-size: 2rem;
            }

            .hero p {
                font-size: 1rem;
            }

            .section-title h2 {
                font-size: 1.8rem;
            }
        }

        @media (max-width: 480px) {
            .services-grid {
                grid-template-columns: 1fr;
            }

            .footer-content {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <header>
        <div class="container">
            <div class="header-content">
                <a href="index.html" class="logo">MediCare OPD</a>
                <nav>
                    <ul>
                        <li><a href="../index.php">Home</a></li>
                        <li><a href="about.html">About Us</a></li>
                        <li><a href="contact.html">Contact</a></li>
                    </ul>
                </nav>
            </div>
        </div>
    </header>

    <section class="hero">
        <div class="container">
            <h1>Our Medical Services</h1>
            <p>Providing comprehensive outpatient care with state-of-the-art facilities and experienced medical professionals</p>
        </div>
    </section>

    <section class="services-section">
        <div class="container">
            <div class="section-title">
                <h2>Our Services</h2>
            </div>
            <div class="services-grid">
                <div class="service-card">
                    <div class="service-icon">
                        <i>🩺</i>
                    </div>
                    <div class="service-content">
                        <h3>General Consultation</h3>
                        <p>Our experienced physicians provide comprehensive medical consultations for a wide range of health concerns, from routine check-ups to specific health issues.</p>
                    </div>
                </div>

                <div class="service-card">
                    <div class="service-icon">
                        <i>💉</i>
                    </div>
                    <div class="service-content">
                        <h3>Vaccination Services</h3>
                        <p>We offer a complete range of vaccinations for all age groups, including routine immunizations, travel vaccines, and seasonal flu shots.</p>
                    </div>
                </div>

                <div class="service-card">
                    <div class="service-icon">
                        <i>🔬</i>
                    </div>
                    <div class="service-content">
                        <h3>Laboratory Services</h3>
                        <p>Our state-of-the-art laboratory provides accurate and timely diagnostic testing, including blood work, urinalysis, and other essential medical tests.</p>
                    </div>
                </div>

                <div class="service-card">
                    <div class="service-icon">
                        <i>🫀</i>
                    </div>
                    <div class="service-content">
                        <h3>Cardiology</h3>
                        <p>Our cardiology department offers comprehensive heart health services, including ECGs, stress tests, and consultations with experienced cardiologists.</p>
                    </div>
                </div>

                <div class="service-card">
                    <div class="service-icon">
                        <i>👶</i>
                    </div>
                    <div class="service-content">
                        <h3>Pediatric Care</h3>
                        <p>Our pediatric specialists provide compassionate care for children of all ages, from newborns to adolescents, focusing on their unique health needs.</p>
                    </div>
                </div>

                <div class="service-card">
                    <div class="service-icon">
                        <i>🦴</i>
                    </div>
                    <div class="service-content">
                        <h3>Orthopedics</h3>
                        <p>Our orthopedic specialists diagnose and treat a wide range of musculoskeletal conditions, from sports injuries to chronic joint pain.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="services-section">
        <div class="container">
            <div class="section-title">
                <h2>Specialized Services</h2>
            </div>
            <div class="services-grid">
                <div class="service-card">
                    <div class="service-icon">
                        <i>🧠</i>
                    </div>
                    <div class="service-content">
                        <h3>Neurology</h3>
                        <p>Our neurology department provides comprehensive care for conditions affecting the brain, spinal cord, and nervous system, with advanced diagnostic capabilities.</p>
                    </div>
                </div>

                <div class="service-card">
                    <div class="service-icon">
                        <i>👁️</i>
                    </div>
                    <div class="service-content">
                        <h3>Ophthalmology</h3>
                        <p>Our eye care specialists provide comprehensive vision services, from routine eye exams to treatment of complex eye conditions.</p>
                    </div>
                </div>

                <div class="service-card">
                    <div class="service-icon">
                        <i>🦷</i>
                    </div>
                    <div class="service-content">
                        <h3>Dental Services</h3>
                        <p>Our dental clinic offers preventive, restorative, and cosmetic dental services for patients of all ages, ensuring optimal oral health.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="cta-section">
        <div class="container">
            <h2>Need to Schedule an Appointment?</h2>
            <p>Our team is ready to provide you with the best medical care</p>
            <a href="contact.html" class="btn">Contact Us Today</a>
        </div>
    </section>

    <footer>
        <div class="container">
            <div class="footer-content">
                <div class="footer-column">
                    <h3>MediCare OPD</h3>
                    <p>Providing quality healthcare services with compassion and excellence since 2005.</p>
                </div>
                <div class="footer-column">
                    <h3>Quick Links</h3>
                    <ul>
                        <li><a href="../index.php">Home</a></li>
                        <li><a href="service.html">Services</a></li>
                        <li><a href="./about.html">About Us</a></li>
                        <li><a href="./contact.html">Contact</a></li>
                    </ul>
                </div>
                <div class="footer-column">
                    <h3>Our Services</h3>
                    <ul>
                        <li><a href="#">General Consultation</a></li>
                        <li><a href="#">Laboratory Services</a></li>
                        <li><a href="#">Cardiology</a></li>
                        <li><a href="#">Pediatric Care</a></li>
                    </ul>
                </div>
                <div class="footer-column contact-info">
                    <h3>Contact Us</h3>
                    <p><i>📍</i> 123 Medical Center Drive, Healthcare City</p>
                    <p><i>📞</i> +1 (555) 123-4567</p>
                    <p><i>✉️</i> info@medicareOPD.com</p>
                </div>
            </div>
            <div class="copyright">
                <p>&copy; 2025 MediCare OPD. All Rights Reserved.</p>
            </div>
        </div>
    </footer>
</body>
</html>