<?php
session_start();
include '../db_connect.php';

// Check if already logged in
if(isset($_SESSION['admin'])) {
    header("Location: admin_dashboard.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = trim($_POST['username']);
    $password = $_POST['password'];

    if(empty($username) || empty($password)) {
        echo "<script>alert('Please fill all fields'); window.location.href='admin_login.html';</script>";
        exit();
    }

    $sql = "SELECT * FROM admin WHERE username = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $admin = $result->fetch_assoc();
        if (password_verify($password, $admin['password'])) {
            $_SESSION['admin'] = $username;
            $_SESSION['admin_id'] = $admin['id'];
            header("Location: admin_dashboard.php");
            exit();
        } else {
            echo "<script>alert('Invalid Credentials'); window.location.href='admin_login.html';</script>";
        }
    } else {
        echo "<script>alert('Invalid Credentials'); window.location.href='admin_login.html';</script>";
    }
    $stmt->close();
}

$conn->close();
?>
