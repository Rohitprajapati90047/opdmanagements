<?php
require_once('../db_connect.php');

// Delete doctor
if (isset($_POST['delete_doctor'])) {
    $doctor_id = $_POST['doctor_id']; // Correct the input field name to 'doctor_id' instead of 'id'
    $sql = "DELETE FROM doctors WHERE id = ?"; // Correct the column name to 'id'
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $doctor_id);
    $stmt->execute();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Doctors</title>
    <link rel="stylesheet" href="../patient/patient_style/dashboard_style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
        }

        .doctor-list {
            width: 90%;
            margin: 2rem auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        .action-btn {
            padding: 8px 16px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            margin-right: 5px;
        }

        .edit-btn { background-color: #2196F3; color: white; }
        .delete-btn { background-color: #f44336; color: white; }
        .add-btn {
            background-color: #4CAF50;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            margin-bottom: 20px;
        }

        /* Responsive styles */
        @media (max-width: 768px) {
            .doctor-list {
                width: 95%;
            }

            table {
                font-size: 14px;
            }

            th, td {
                padding: 8px;
            }

            .action-btn {
                padding: 6px 12px;
            }

            .edit-btn, .delete-btn {
                font-size: 12px;
            }
            .add-btn {
    background-color: #4CAF50;
    color: white;
    padding: 10px 20px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    margin-bottom: 20px;
    text-decoration: none; /* ensures it's styled like a button */
    display: inline-block; /* this prevents full width */
}


            /* Make the table scrollable horizontally on small screens */
            .table-container {
                overflow-x: auto;
                -webkit-overflow-scrolling: touch;
            }
        }

        @media (max-width: 480px) {
            th, td {
                padding: 6px;
            }

            .action-btn {
                padding: 5px 10px;
            }

            .doctor-list h1 {
                font-size: 1.5rem;
            }

            /* Stack action buttons vertically on smaller screens */
            .action-btn {
                width: 100%;
                margin-bottom: 5px;
            }
        }
    </style>
</head>
<body>
    <?php include './nav/navbar.php'; ?>
    <div class="doctor-list">
        <h1>Manage Doctors</h1>

        <div style="display: flex; justify-content: flex-end; margin-bottom: 10px;">
    <a href="../doctor/register_doctor.php" class="add-btn">Add New Doctor</a>
</div>

        <div class="table-container">
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Specialization</th>
                        <th>Email</th>
                        <th>Phone</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $sql = "SELECT * FROM doctors";
                    $result = $conn->query($sql);

                    while ($row = $result->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td>{$row['id']}</td>";
                        echo "<td>{$row['name']}</td>";
                        echo "<td>{$row['disease_type']}</td>";
                        echo "<td>{$row['email']}</td>";
                        echo "<td>{$row['phone']}</td>";
                        echo "<td>
                                <a href='../admin/edit_profileby_admin.php?id={$row['id']}' class='action-btn edit-btn'>Edit</a>
                                <form style='display: inline;' method='POST'>
                                    <input type='hidden' name='doctor_id' value='{$row['id']}'>
                                    <button type='submit' name='delete_doctor' class='action-btn delete-btn'>Delete</button>
                                </form>
                              </td>";
                        echo "</tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>

