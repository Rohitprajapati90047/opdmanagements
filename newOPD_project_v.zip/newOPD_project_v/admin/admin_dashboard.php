
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="./admdashbordstyle.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>
        .dashboard-buttons {
            display: flex;
            justify-content: center;
            gap: 2rem;
            margin-top: 2rem;
        }
        .dashboard-btn {
            display: flex;
            flex-direction: column;
            align-items: center;
            padding: 2rem;
            border: none;
            border-radius: 10px;
            background-color: #4CAF50;
            color: white;
            cursor: pointer;
            transition: all 0.3s ease;
            width: 200px;
        }
        .dashboard-btn:hover {
            transform: translateY(-5px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
        }
        .dashboard-btn i {
            font-size: 3rem;
            margin-bottom: 1rem;
        }
        .doctor-btn {
            background-color:rgb(255, 143, 15);
        }
        .patient-btn {
            background-color:rgb(0, 239, 24);
        }
    </style>
</head>
<body>
    <?php include './nav/navbar.php'; ?>
    <h1 style="text-align: center;">Admin Dashboard</h1>
    <div class="dashboard-buttons">
        <a href="manage_doctors.php" class="dashboard-btn doctor-btn">
            <i class="fas fa-user-md"></i>
            <span>Manage Doctors</span>
        </a>
        <a href="manage_patients.php" class="dashboard-btn patient-btn">
            <i class="fas fa-hospital-user"></i>
            <span>Manage Patients</span>
        </a>
    </div>
</body>
</html>
<?php include '../footer.php'; ?>