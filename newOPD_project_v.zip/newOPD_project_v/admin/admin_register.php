<?php
session_start();
include '../db_connect.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $fullname = trim($_POST['fullname']);
    $username = trim($_POST['username']);
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];

    // Validation
    if(empty($fullname) || empty($username) || empty($email) || empty($password) || empty($confirm_password)) {
        echo "<script>alert('Please fill all fields'); window.location.href='admin_register.html';</script>";
        exit();
    }

    if($password !== $confirm_password) {
        echo "<script>alert('Passwords do not match'); window.location.href='admin_register.html';</script>";
        exit();
    }

    if(!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo "<script>alert('Invalid email format'); window.location.href='admin_register.html';</script>";
        exit();
    }

    // Check if username already exists
    $check_sql = "SELECT * FROM admin WHERE username = ? OR email = ?";
    $check_stmt = $conn->prepare($check_sql);
    $check_stmt->bind_param("ss", $username, $email);
    $check_stmt->execute();
    $result = $check_stmt->get_result();

    if ($result->num_rows > 0) {
        echo "<script>alert('Username or Email already exists'); window.location.href='admin_register.html';</script>";
        exit();
    }

    // Hash password
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    // Insert new admin
    $sql = "INSERT INTO admin (fullname, username, email, password) VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssss", $fullname, $username, $email, $hashed_password);

    if ($stmt->execute()) {
        echo "<script>alert('Registration successful! Please login.'); window.location.href='admin_login.html';</script>";
    } else {
        echo "<script>alert('Registration failed! Please try again.'); window.location.href='admin_register.html';</script>";
    }

    $stmt->close();
}

$conn->close();
?>