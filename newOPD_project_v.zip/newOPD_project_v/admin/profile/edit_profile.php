<?php
session_start();
if (!isset($_SESSION['admin_id'])) {
    header("Location: ../admin_login.php");
    exit();
}
include '../../db_connect.php';

$admin_id = $_SESSION['admin_id'];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $email = $_POST['email'];
    $fullname = $_POST['fullname'];
   
    
    $update_query = $conn->prepare("UPDATE admin SET username = ?, email = ?, fullname = ? WHERE id = ?");
    $update_query->bind_param("sssi", $username, $email, $fullname, $admin_id);
    
    if ($update_query->execute()) {
        header("Location: view_profile.php");
        exit();
    }
}

$admin_query = $conn->query("SELECT * FROM admin WHERE id = '$admin_id'");
$admin = $admin_query->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Admin Profile</title>
    <link rel="stylesheet" href="../../dashboard_style.css">
    <style>
        .edit-profile-section {
            background: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            margin: 20px auto;
            max-width: 600px;
        }
        .form-field {
            margin-bottom: 15px;
        }
        .form-field label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
            color: #333;
        }
        .form-field input {
            width: 100%;
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 4px;
        }
        .save-btn {
            background: #4CAF50;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        .save-btn:hover {
            background: #45a049;
        }
    </style>
</head>
<body>
    <?php include '../../navbar.php'; ?>
    <div class="edit-profile-section">
        <h2>Edit Profile</h2>
        <form method="POST">
            <div class="form-field">
                <label>Username:</label>
                <input type="text" name="username" value="<?php echo htmlspecialchars($admin['username']); ?>" required>
            </div>
            <div class="form-field">
                <label>Email:</label>
                <input type="email" name="email" value="<?php echo htmlspecialchars($admin['email']); ?>" required>
            </div>
            <div class="form-field">
                <label>Full Name:</label>
                <input type="text" name="fullname" value="<?php echo htmlspecialchars($admin['fullname']); ?>" required>
            </div>
            
            <button type="submit" class="save-btn">Save Changes</button>
        </form>
    </div>
</body>
</html>