<?php
session_start();
if (!isset($_SESSION['admin_id'])) {
    header("Location: ../admin_login.php");
    exit();
}
include '../../db_connect.php';

// Get admin's information
$admin_id = $_SESSION['admin_id'];
$admin_query = $conn->query("SELECT * FROM admin WHERE id = '$admin_id'");
$admin = $admin_query->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Profile</title>
    <link rel="stylesheet" href="../../patient/patient_style/dashboard_style.css">
    <style>
        .profile-section {
            background: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            margin: 20px auto;
            max-width: 600px;
        }
        .profile-info {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 15px;
        }
        .profile-field {
            margin-bottom: 10px;
        }
        .profile-field label {
            font-weight: bold;
            display: block;
            margin-bottom: 5px;
            color: #333;
        }
        .profile-field span {
            color: #666;
        }
        .edit-profile-btn {
            background: #2196F3;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            margin-top: 10px;
            text-align: center;
            display: block;
            text-decoration: none;
        }
        .edit-profile-btn:hover {
            background: #1976D2;
        }
    </style>
</head>
<body>
    <?php include '../nav/no_profile_navbar.php'; ?>
    <div class="profile-section">
        <h2>Admin Profile</h2>
        <div class="profile-info">
            <div class="profile-field">
                <label>Username:</label>
                <span><?php echo htmlspecialchars($admin['username']); ?></span>
            </div>
            <div class="profile-field">
                <label>Email:</label>
                <span><?php echo htmlspecialchars($admin['email']); ?></span>
            </div>
            <div class="profile-field">
                <label>Full Name:</label>
                <span><?php echo htmlspecialchars($admin['fullname']); ?></span>
            </div>
            <div class="profile-field">
                <label>Created At:</label>
                <span><?php echo htmlspecialchars($admin['created_at']); ?></span>
            </div>
        </div>
        <a href="edit_profile.php" class="edit-profile-btn">Edit Profile</a>
    </div>
</body>
</html>