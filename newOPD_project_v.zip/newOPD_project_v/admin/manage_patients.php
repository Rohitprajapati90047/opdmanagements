<?php
require_once('../db_connect.php');

// Delete patient
if (isset($_POST['delete_patient'])) {
    $patient_id = $_POST['patient_id'];
    $sql = "DELETE FROM patient WHERE patient_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $patient_id);
    $stmt->execute();
}

// Function to calculate age from DOB
function calculateAge($dob) {
    $birthDate = new DateTime($dob);
    $today = new DateTime('today');
    $age = $birthDate->diff($today)->y;
    return $age;
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Patients</title>
    <link rel="stylesheet" href="../patient/patient_style/dashboard_style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">

    <!-- Internal CSS for responsiveness -->
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        .patient-list {
            width: 90%;
            margin: 2rem auto;
            padding: 10px;
        }

        h1 {
            text-align: center;
            margin-bottom: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
            table-layout: auto;
        }

        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        th {
            background-color: #f2f2f2;
        }

        .action-btn {
            padding: 8px 16px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            margin-right: 5px;
        }

        .edit-btn { background-color: #2196F3; color: white; }
        .delete-btn { background-color: #f44336; color: white; }
        .upload-btn { background-color: #FF9800; color: white; }
        .add-btn {
            background-color: #4CAF50;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            margin-bottom: 20px;
            display: inline-block;
            text-align: center;
        }

        /* Responsive Styles */
        @media (max-width: 768px) {
            .patient-list {
                /* width: 100%; */
                padding: 1rem;
            }

            table {
                font-size: 14px;
                width: 100%;
                overflow-x: auto;
                display: block;
            }

            th, td {
                padding: 10px;
            }

            .action-btn {
                padding: 8px 12px;
                font-size: 14px;
                width: 100%;
                text-align: center;
                margin-bottom: 10px;
            }

            .action-btn:last-child {
                margin-bottom: 0;
            }

            .add-btn {
                width: 100%;
                padding: 12px;
                font-size: 16px;
            }

            .patient-list h1 {
                font-size: 24px;
            }
        }

        @media (max-width: 480px) {
            th, td {
                font-size: 12px;
            }

            .action-btn {
                font-size: 12px;
                padding: 6px 10px;
            }

            .add-btn {
                font-size: 14px;
                padding: 10px;
            }

            .patient-list h1 {
                font-size: 20px;
            }

            /* Make the form buttons and links stack on top of each other */
            .action-btn {
                display: block;
                margin: 10px 0;
            }

            table {
                font-size: 12px;
                display: block;
                overflow-x: auto;
            }
        }
    </style>
</head>
<body>
    <?php include './nav/navbar.php'; ?>
    <div class="patient-list">
        <h1>Manage Patients</h1>
        <!-- <a href="add_patient.php" class="add-btn">Add New Patient</a> -->
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Age</th>
                    <th>Gender</th>
                    <th>Phone</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $sql = "SELECT * FROM patient";
                $result = $conn->query($sql);

                while ($row = $result->fetch_assoc()) {
                    $age = calculateAge($row['dob']); // Calculate age from DOB
                    echo "<tr>";
                    echo "<td>{$row['patient_id']}</td>";
                    echo "<td>{$row['fname']} {$row['lname']}</td>";
                    echo "<td>{$age}</td>"; // Display calculated age instead of stored age
                    echo "<td>{$row['gender']}</td>";
                    echo "<td>{$row['phone']}</td>";
                    echo "<td>
                             <form style='display: inline;' method='POST'>
                                <input type='hidden' name='patient_id' value='{$row['patient_id']}'>
                                <button type='submit' name='delete_patient' class='action-btn delete-btn'>Delete</button>
                            </form>
                            <a href='../reports/upload_report.php?id={$row['patient_id']}' class='action-btn upload-btn'>Upload Report</a>
                          </td>";
                    echo "</tr>";
                }
                ?>
            </tbody>
        </table>
    </div>
</body>
</html>
