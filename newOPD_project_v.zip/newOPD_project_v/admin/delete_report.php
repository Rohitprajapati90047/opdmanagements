<?php
// Start the session
session_start();

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $servername = "localhost";
    $username = "root";
    $password = "";
    $database = "opd_management";

    // Connect to the database
    $conn = new mysqli($servername, $username, $password, $database);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Get the report ID from the form
    $report_id = $_POST['report_id'];

    // Get the file path from the database
    $sql = "SELECT file_path FROM lab_reports WHERE id = '$report_id'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $file_path = $_SERVER['DOCUMENT_ROOT'] . "/OPD_Project/" . $row['file_path'];

        // Delete the file from the server
        if (file_exists($file_path)) {
            unlink($file_path);
        }

        // Delete the record from the database
        $delete_sql = "DELETE FROM lab_reports WHERE id = '$report_id'";
        if ($conn->query($delete_sql) === TRUE) {
            echo "<p>Report deleted successfully!</p>";
        } else {
            echo "<p>Error deleting report: " . $conn->error . "</p>";
        }
    } else {
        echo "<p>Report not found!</p>";
    }

    $conn->close();
}
?>

<h2>Delete Lab Report</h2>
<form method="POST">
    Report ID: <input type="number" name="report_id" required><br><br>
    <button type="submit">Delete Report</button>
</form>
