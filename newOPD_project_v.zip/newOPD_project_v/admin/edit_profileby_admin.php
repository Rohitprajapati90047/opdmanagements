<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "opd_management";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Initialize variables
$id = isset($_GET['id']) ? intval($_GET['id']) : 0;
$success = "";
$error = "";

// If the form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = intval($_POST['id']);
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $specialization = $_POST['specialization'];
    $license_no = $_POST['license_no'];
    $disease_type = $_POST['disease_type'];

    // Update query
    $sql = "UPDATE doctors 
            SET name = '$name', email = '$email',
                phone = '$phone', specialization = '$specialization',
                license_no = '$license_no', disease_type = '$disease_type'
            WHERE id = $id";

    if ($conn->query($sql) === TRUE) {
        $success = "Profile updated successfully.";
        // Redirect after 3 seconds
        echo "<script>
                setTimeout(function() {
                    window.location.href = '../admin/manage_doctors.php'; 
                }, 000);
              </script>";
    } else {
        $error = "Error updating profile: " . $conn->error;
    }
}

// Retrieve user data if ID is provided
$doctors = null;
if ($id > 0) {
    $sql = "SELECT * FROM doctors WHERE id = $id";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        $doctors = $result->fetch_assoc();
    } else {
        $error = "No user found with ID $id.";
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Profile</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            background-color: #f9f9f9;
        }
        h1 {
            text-align: center;
            color: #333;
        }
        form {
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            max-width: 400px;
            margin: 20px auto;
        }
        label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }
        input {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 3px;
        }
        button {
            width: 100%;
            padding: 10px;
            border: none;
            border-radius: 3px;
            background-color: #007bff;
            color: white;
            font-size: 16px;
            cursor: pointer;
        }
        button:hover {
            background-color: #0056b3;
        }
        .message {
            text-align: center;
            font-size: 16px;
            margin-bottom: 20px;
        }
        .success {
            color: green;
        }
        .error {
            color: red;
        }

        @media (max-width: 768px) {
            form {
                width: 90%;
            }
            h1 {
                font-size: 24px;
            }
        }
        @media (max-width: 480px) {
            form {
                width: 95%;
            }
            h1 {
                font-size: 20px;
            }
            button {
                font-size: 14px;
                padding: 12px;
            }
        }
    </style>
</head>
<body>
    <h1>Edit Profile</h1>

    <?php if ($success): ?>
        <p class="message success"><?php echo $success; ?></p>
    <?php endif; ?>

    <?php if ($error): ?>
        <p class="message error"><?php echo $error; ?></p>
    <?php endif; ?>

    <?php if ($doctors): ?>
        <form action="" method="post">
            <input type="hidden" name="id" value="<?php echo $doctors['id']; ?>">

            <label for="name">Name:</label>
            <input type="text" id="name" name="name" value="<?php echo $doctors['name']; ?>">

            <label for="email">Email:</label>
            <input type="email" id="email" name="email" value="<?php echo $doctors['email']; ?>">

            <label for="phone">Phone:</label>
            <input type="text" id="phone" name="phone" value="<?php echo $doctors['phone']; ?>">

            <label for="specialization">Specialization:</label>
            <input type="text" id="specialization" name="specialization" value="<?php echo $doctors['specialization']; ?>">

            <label for="license_no">License No:</label>
            <input type="text" id="license_no" name="license_no" value="<?php echo $doctors['license_no']; ?>">

            <label for="disease_type">Disease Type:</label>
            <input type="text" id="disease_type" name="disease_type" value="<?php echo $doctors['disease_type']; ?>">

            <button type="submit">Update Profile</button>
        </form>
    <?php endif; ?>
</body>
</html>
