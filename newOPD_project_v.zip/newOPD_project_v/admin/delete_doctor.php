<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header("Location: admin_login.html");
    exit();
}

include '../db_connect.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    
    $stmt = $conn->prepare("DELETE FROM doctors WHERE id = ?");
    $stmt->bind_param("i", $id);
    
    if ($stmt->execute()) {
        echo "<script>alert('Doctor deleted successfully'); window.location.href='admin_dashboard.php';</script>";
    } else {
        echo "<script>alert('Error deleting doctor'); window.location.href='admin_dashboard.php';</script>";
    }
    
    $stmt->close();
}

$conn->close();
?>