<html>
<head>
    <title>Footer</title>
    <style>
        /* General footer styles */
        .footer {
            background-color: #2c3e50;
            color: #ecf0f1;
            padding: 40px 0;
            margin-top: 50px;
        }

        .footer-container {
            display: flex;
            flex-wrap: wrap;
            justify-content: space-around;
            max-width: 1200px;
            margin: 0 auto;
        }

        .footer-section {
            flex: 1 1 200px;
            margin: 20px;
        }

        h3 {
            margin-bottom: 20px;
            font-size: 20px;
            color: #ecf0f1;
            border-bottom: 2px solid #ecf0f1;
            padding-bottom: 8px;
        }

        a {
            display: block;
            margin: 8px 0;
            color: #bdc3c7;
            text-decoration: none;
        }

        p {
            text-align: center;
            margin-top: 20px;
            color:rgb(190, 195, 198);
            font-size: 14px;
        }

        /* Responsive styles */
        @media (max-width: 768px) {
            .footer-container {
                flex-direction: column;
                align-items: center;
            }

            .footer-section {
                flex: 1 1 100%;
                margin: 10px 0;
                text-align: center;
            }

            h3 {
                font-size: 18px;
            }

            a {
                font-size: 14px;
            }

            p {
                font-size: 12px;
            }
        }

        @media (max-width: 480px) {
            .footer-section {
                flex: 1 1 100%;
                margin: 10px 0;
                text-align: center;
            }

            h3 {
                font-size: 16px;
            }

            a {
                font-size: 12px;
            }

            p {
                font-size: 10px;
            }
        }
    </style>
</head>
<body>
    <div class="footer">
        <div class="footer-container">
            <!-- Department and Services Section -->
            <div class="footer-section">
                <h3>Departments and Services</h3>
                <a href="#">Centres of Excellence</a>
                <a href="#">Clinical Departments</a>
                <a href="#">Clinics at KH</a>
                <a href="#">Support Groups</a>
                <a href="#">More</a>
            </div>

            <!-- Patients and Visitors Section -->
            <div class="footer-section">
                <h3>Patients and Visitors</h3>
                <a href="#">Find A Doctor</a>
                <a href="#">Make an Appointment</a>
                <a href="#">Virtual Tour</a>
                <a href="#">Testimonials</a>
                <a href="#">More</a>
            </div>

            <!-- Medical Professionals Section -->
            <div class="footer-section">
                <h3>Medical Professionals</h3>
                <a href="#">Doctor's Profiles</a>
                <a href="#">Refer A Patient</a>
                <a href="#">Awards</a>
                <a href="#">More</a>
            </div>

            <!-- Site Information Section -->
            <div class="footer-section">
                <h3>Site Information</h3>
                <a href="#">Sitemap</a>
                <a href="#">Privacy Policy</a>
                <a href="#">Conditions of Use</a>
                <a href="#">Cookies Policy</a>
            </div>

            <!-- About Section -->
            <!-- <div class="footer-section">
                <h3>About</h3>
                <a href="#">Our Chairperson</a>
                <a href="#">CSR at KDAH</a>
                <a href="#">Discover our Logo</a>
                <a href="#">Philosophy</a>
                <a href="#">More</a>
            </div> -->

            <!-- Uncomment to add social media links
            <div class="footer-section">
                <h3>Get In Touch</h3>
                <div class="social-icons">
                    <a href="#">Facebook</a>
                    <a href="#">Twitter</a>
                    <a href="#">YouTube</a>
                    <a href="#">Instagram</a>
                    <a href="#">LinkedIn</a>
                </div>
            </div>
            -->
        </div>
        <p>&copy; <?php echo date("Y"); ?> OPD Management System. All rights reserved.</p>
    </div>
</body>
</html>
