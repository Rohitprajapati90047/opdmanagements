<?php
header('Content-Type: application/json');

// Connect to database
$host = "localhost";
$user = "root";
$pass = "";
$dbname = "opd_management"; // change this to your actual DB name

$conn = new mysqli($host, $user, $pass, $dbname);

if ($conn->connect_error) {
    echo json_encode(['error' => 'Database connection failed']);
    exit;
}

// Query total visits (assuming you have a `visits` table)
$visitQuery = $conn->query("SELECT COUNT(*) AS total_visits FROM website_visits");
$visitData = $visitQuery->fetch_assoc();

// Query total registrations (assuming you have a `users` table)
$registerQuery = $conn->query("SELECT COUNT(*) AS total_registrations FROM patient");
$registerData = $registerQuery->fetch_assoc();

// Return as JSON
echo json_encode([
    'visits' => $visitData['total_visits'],
    'registrations' => $registerData['total_registrations']
]);

$conn->close();
