<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Responsive Login Options with Icons</title>
    <!-- Font Awesome CDN -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        .login-buttons {
            display: flex;
            justify-content: center;
            gap: 10px;
            margin-top: 50px;
            flex-wrap: wrap; /* Allow wrapping on smaller screens */
        }
    
        .btn {
            padding: 15px 25px;
            color: white;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-size: 20px; /* Increased font size */
            display: flex;
            align-items: center;
            gap: 10px;
            transition: background-color 0.3s, transform 0.2s;
            flex: 1 1 180px; /* Responsive width */
            margin: 5px;
        }
    
        /* Button Colors */
        .btn-doctor {
            background-color: #28a745;
        }
        .btn-doctor:hover {
            background-color: #218838;
            transform: scale(1.05);
        }
    
        .btn-patient {
            background-color: #17a2b8;
        }
        .btn-patient:hover {
            background-color: #138496;
            transform: scale(1.05);
        }
    
        .btn-admin {
            background-color: #ffc107;
            color: black;
        }
        .btn-admin:hover {
            background-color: #e0a800;
            transform: scale(1.05);
        }
    
        .btn-feature {
            background-color: #dc3545;
        }
        .btn-feature:hover {
            background-color: #c82333;
            transform: scale(1.05);
        }
    
        .btn i {
            font-size: 124px; /* Increased icon size */
        }
    
        /* Responsive for smaller screens */
        @media (max-width: 600px) {
            .login-buttons {
                flex-direction: column;
                align-items: center;
            }
    
            .btn {
                width: 90%; /* Full width on small screens */
                font-size: 22px; /* Larger font on small screens */
            }
    
            .btn i {
                font-size: 28px; /* Larger icon size on small screens */
            }
        }
    </style>
    
    <link rel="stylesheet" type="text/css" href="./patient/patient_style/dashboard_style.css">
</head>
<body>
<?php include './patient/nav/back.html'; ?>
    <h1 style="text-align: center;">Choose your login option</h1>

    <div class="login-buttons">
    <button class="btn btn-doctor" onclick="location.href='./doctor/doctor_login.php'">
    <i class="fas fa-user-md"></i>Doctor Login
</button>
<button class="btn btn-patient" onclick="location.href='patient/login.html'">
    <i class="fas fa-user"></i>Patient Login
</button>
<button class="btn btn-admin" onclick="location.href='./admin/admin_login.html'">
    <i class="fas fa-user-shield"></i>Admin Login
</button>

    </div>
  
</body>

</html>
