<?php
session_start();
require('razorpay-php/Razorpay.php'); // Include Razorpay library

use Razorpay\Api\Api;

$apiKey = "YOUR_RAZORPAY_KEY";
$apiSecret = "YOUR_RAZORPAY_SECRET";

$api = new Api($apiKey, $apiSecret);

$orderData = [
    'amount' => 1000, // Payment amount in paise (₹10.00)
    'currency' => 'INR',
    'payment_capture' => 1, // Auto-capture payment
];

$order = $api->order->create($orderData);
echo json_encode(['order_id' => $order['id']]);
?>
