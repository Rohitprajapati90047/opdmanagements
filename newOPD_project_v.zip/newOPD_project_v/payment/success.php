<?php
echo "<h1>Payment and Appointment Successful!</h1>";
echo "<a href='dashboard.php'>Back to Dashboard</a>";
?>
